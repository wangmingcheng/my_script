from SupspotROI import SupspotROI
import cv2
import os
import getopt
import sys

# os.makedirs('D:/outdir/hello/world/')
# exit()




def open_level_gene_matrix(level_dir):
    # init
    levels = []
    # 提取目录下的levels
    os_walk = os.walk(level_dir)
    _, dirs, _ = os_walk.__next__()
    for curr_dir in dirs:
        if len(curr_dir) < 7:
            continue
        if curr_dir[0:6] == 'level_':
            print(f"{curr_dir}")
            levels.append(int(curr_dir[6:]))
    if len(levels) == 0:
        return 0
    levels.sort(reverse=True)
    return levels
    pass





def gen_one_roi_level_matrix(img_ori, curr_level, outdir, level_dir, roi_json_file, roi_key='heAuto'):
    # 构建SupspotROI
    sroi = SupspotROI(img_ori, curr_level)

    # 创建输出目录
    subdata_key = f"L{curr_level}_{roi_key}"
    subdata_dir = f"{outdir}/subdata/{subdata_key}/"
    if not os.path.exists(subdata_dir):
        os.makedirs(subdata_dir)
    # 生成subdata
    level_dir = f"{level_dir}/level_{curr_level}/"
    json_file = roi_json_file
    roi_group = sroi.read_roi_group_f_file(json_file)
    roi_mask = sroi.cal_roi_group_mask(roi_group)
    sroi.link_level_roi(level_dir=level_dir, roi_mask=roi_mask, outdir=subdata_dir)
    pass




def do_something(used_args):
    # open img
    img_ori = cv2.imread(used_args['he_file'])
    img_ori = img_ori[:, :, [2, 1, 0]]

    # get levels
    levels = open_level_gene_matrix(used_args['matrix_dir'])
    print(f"levels:{levels}")

    for curr_level in levels:
        # gen_one_roi_level_matrix(img_ori, curr_level, used_args['outdir'], used_args['matrix_dir'], used_args['roi_file'], roi_key='allhe')
        gen_one_roi_level_matrix(img_ori, curr_level, used_args['outdir'], used_args['matrix_dir'], used_args['roi_file'],
                             roi_key='heAuto')
    pass


def usage():
    print("======="*10)
    print("Usage:")
    print("1) python levelMatrix.py -i ./test.tif -o ./outdir/")
    print("2) python levelMatrix.py --infile ./test.tif --outdir ./outdir/")
    print("3) python levelMatrix.py -h")
    print("4) python levelMatrix.py --help")
    print("======="*10)
    exit()



def main():
    # init
    short_opts = 'he:m:o:r:'
    long_opts = ['help', 'he_file=', 'matrix_dir=', 'outdir=', 'roi_file=']
    args_names = [None, 'he_file', 'matrix_dir', 'outdir', 'roi_file']
    # options, args = getopt.getopt(sys.argv[1:], 'he:m:o:r:', ['help', 'he_file=', 'matrix_dir=', 'outdir=', 'roi_file='])

    # 生成required_options与opts_2_names
    ss = short_opts.replace(':','')
    required_options = []
    opts_2_names = {}
    for i in range(len(args_names)):
        if args_names[i] is None:
            continue
        else:
            short_o = '-' + ss[i]
            long_o = '--' + long_opts[i].replace('=','')
            required_options.append([short_o,long_o])
            opts_2_names[short_o] = args_names[i]
            opts_2_names[long_o] = args_names[i]

    # getopt
    options_dict = {}
    used_args = {}
    options, args = getopt.getopt(sys.argv[1:], short_opts, long_opts)
    for name, value in options:
        if name not in options_dict.keys():
            options_dict[name] = value
        if name in opts_2_names.keys():
            used_args[opts_2_names[name]] = value
    print(used_args)

    if '-h' in options_dict.keys() or '--help' in options_dict.keys():
        usage()

    # 检查必需提供的参数是否被提供，没有就提示一下，并打印使用说明
    for short_o, long_o in required_options:
        if short_o not in options_dict.keys() and long_o not in options_dict.keys():
            print(f"{short_o} or {long_o} must exist")
            usage()

    do_something(used_args)



if __name__ == "__main__":
    main()








