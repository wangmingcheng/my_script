import copy
import json
import os
import sys

import numpy as np
import cv2
import pandas as pd
import shutil
import gzip
import io

import matplotlib.pyplot as plt

# 定义图片展示函数
ShowImageType = 1
def img_show(name, img):
    if ShowImageType == 0:
        cv2.imshow(name, img)
        cv2.waitKey(0)
        cv2.destroyAllWindows()
    else:
        plt.imshow(img)
        plt.title(name)
        plt.show()


class SupspotROI():
    def __init__(self, he_img, slide_len):
        self.he_img = he_img
        self.he_width = he_img.shape[1]
        self.he_height = he_img.shape[0]

        self.std_chip_zoom = 1.0
        self.update_zoom_by_he_img(self.he_width, self.he_height)

        self.chip_width = 1000 * self.std_chip_zoom
        self.chip_height = 1000 / (46*31) * (46*36*np.sqrt(3)/2) * self.std_chip_zoom
        self.center_dist = self.chip_width / (46*31)
        self.slide_height = ((slide_len - 1)+0.5) * self.center_dist * np.sqrt(3) / 2

        print(f"self.he_width={self.he_width},self.chip_width={self.chip_width},self.std_chip_zoom={self.std_chip_zoom}")

        pass
    def update_zoom_by_he_img(self, width, height):
        std_width = 1000
        std_height = std_width / (46*31) * (46 * 36 * np.sqrt(3) / 2.0)
        if std_width/std_height > width/height:
            self.std_chip_zoom = width / std_width
        else:
            self.std_chip_zoom = height / std_height
        pass

    def link_level_roi(self, level_dir, roi_mask, outdir):
        if not os.path.exists(outdir):
            os.mkdir(outdir)
        # 拷贝基因列表文件
        gene_list_file = f"{level_dir}/features.tsv.gz"
        shutil.copy(gene_list_file, outdir)
        df = pd.read_csv(gene_list_file, compression='gzip', sep='\t', header=None)
        gene_num = df.shape[0]
        print("gene list file is ok")

        # supspot列表与位置文件
        pos_file = f"{level_dir}/barcodes_pos.tsv.gz"
        df = pd.read_csv(pos_file, compression='gzip', sep='\t', names=['name', 'pos_w', 'pos_h'], header=None)
        new_pos_file = f"{outdir}/barcodes_pos.tsv.gz"

        # supspot位置文件
        sub_supspot_list = []
        sub_supspot_index = {}
        old_supspot_index = []
        with gzip.open(new_pos_file, "wb") as fp_gzip:
            with io.TextIOWrapper(fp_gzip, encoding='utf-8') as fp:
                for index, item in df.iterrows():
                    center_x = int(item['pos_w'] * self.std_chip_zoom)
                    center_y = int(item['pos_h'] * self.std_chip_zoom)
                    if center_x < 0 or center_x >= self.he_width:
                        continue
                    if center_y < 0 or center_y >= self.he_height:
                        continue
                    if roi_mask[center_y, center_x] > 0:
                        sub_supspot_list.append(item['name'])
                        sub_supspot_index[index+1] = len(sub_supspot_list)
                        old_supspot_index.append(index+1)
                        fp.write(f"{item['name']}\t{item['pos_w']}\t{item['pos_h']}\n")
        print("supspot pos is ok")
        # supspot列表
        new_bc_file = f"{outdir}/barcodes.tsv.gz"
        with gzip.open(new_bc_file, "wb") as fp_gzip:
            with io.TextIOWrapper(fp_gzip, encoding='utf-8') as fp:
                for id in sub_supspot_list:
                    fp.write(f"{id}\n")
        print("supspot list is ok")

        # 基因表达矩阵文件
        gene_matrix_file = f"{level_dir}/matrix.mtx.gz"
        df = pd.read_csv(gene_matrix_file, compression='gzip', sep='\t', names=['gene', 'supspot', 'umi'], skiprows=3, header=None)
        print("reading is ok")
        sub_df = df[df['supspot'].isin(old_supspot_index)].copy()
        umi_num_sum = sub_df['umi'].sum()
        supspot_num = len(sub_supspot_list)
        print("sub is ok")
        new_gene_matrix_file = f"{outdir}/matrix.mtx.gz"

        sub_df.loc[:,'supspot'] = sub_df['supspot'].apply(lambda x:sub_supspot_index[x])
        print(f"sub_df:{sub_df.info()}")
        print(f"sub_df.head():{sub_df.head()}")
        content = sub_df.to_csv(sep='\t',header=False,index=False,line_terminator='\n')
        # content = f"%%MatrixMarket matrix coordinate real general\n%\n{gene_num}\t{supspot_num}\t{umi_num_sum}\n" + content
        content = f"%%MatrixMarket matrix coordinate real general\n%\n{gene_num}\t{supspot_num}\t{sub_df.shape[0]}\n" + content
        content = content.encode()
        with gzip.open(new_gene_matrix_file, "wb") as fp_gzip:
            fp_gzip.write(content)
        print("gene exp matrix is ok")
        pass

    def gen_roi_cluster_img(self, pos_file, cluser_file):
        cluster_df = pd.read_csv(cluser_file, sep=',', names=['name', 'cluster'], header=0)
        pos_df = pd.read_csv(pos_file, compression='gzip', sep='\t', names=['name', 'pos_w', 'pos_h'], header=None)
        cluster_pos_df = pos_df[pos_df['name'].isin(cluster_df['name'])]
        cluster_pos_df = pd.merge(cluster_pos_df, cluster_df)
        cluster_pos_df['pos_w'] = cluster_pos_df['pos_w'] * self.std_chip_zoom
        cluster_pos_df['pos_h'] = cluster_pos_df['pos_h'] * self.std_chip_zoom
        cluster_pos_df.round({'pos_w':0, 'pos_h':0})
        print(f"pos:{pos_df.shape[0]}, cluster:{cluster_df.shape[0]}, cluster_pos:{cluster_pos_df.shape}")
        print(f"col name list:{cluster_pos_df.columns.to_list()}")
        return cluster_pos_df

    # def gen_roi_umi_img(self, matrix_dir):
    #     matrix_file = f'{matrix_dir}/matrix.mtx.gz'
    #     matrix_df = pd.read_csv(matrix_file, sep=',', names=['name', 'cluster'], header=0)
    #     pos_file = f'{matrix_dir}/barcodes_pos.tsv.gz'
    #     pos_df = pd.read_csv(pos_file, compression='gzip', sep='\t', names=['name', 'pos_w', 'pos_h'], header=None)
    #     cluster_pos_df = pos_df[pos_df['name'].isin(cluster_df['name'])]
    #     cluster_pos_df = pd.merge(cluster_pos_df, cluster_df)
    #     cluster_pos_df['pos_w'] = cluster_pos_df['pos_w'] * self.std_chip_zoom
    #     cluster_pos_df['pos_h'] = cluster_pos_df['pos_h'] * self.std_chip_zoom
    #     cluster_pos_df.round({'pos_w':0, 'pos_h':0})
    #     print(f"pos:{pos_df.shape[0]}, cluster:{cluster_df.shape[0]}, cluster_pos:{cluster_pos_df.shape}")
    #     print(f"col name list:{cluster_pos_df.columns.to_list()}")
    #     return cluster_pos_df

    def stat_supspot_num(self, pos_file):
        df = pd.read_csv(pos_file, compression='gzip', sep='\t', names=['name', 'pos_w', 'pos_h'], header=None)
        return df.shape[0]
        pass

    def cal_roi_group_mask(self, roi_group):
        roi_mask = np.zeros(self.he_img.shape[0:2], dtype='uint8')
        for roi in roi_group:
            if len(roi) <= 3:
                continue
            contours = np.array(roi, dtype=int)
            cv2.fillPoly(roi_mask, [contours], 255)  # 填充内部
            # cv2.fillPoly(img,contours,(255,0,0)) #只染色边界
        return roi_mask
        pass

    def draw_level_supspot_on_he(self, level_dir):
        pos_file = f"{level_dir}/barcodes_pos.tsv.gz"
        df = pd.read_csv(pos_file, compression='gzip', sep='\t', names=['name','pos_w','pos_h'])
        print(df.shape)

        df['pos_w'] = df['pos_w'] * self.std_chip_zoom
        df['pos_h'] = df['pos_h'] * self.std_chip_zoom
        radius = int(self.slide_height * 0.7)

        he_img2 = copy.deepcopy(self.he_img)
        for index, item in df.iterrows():
            center_x = int(item['pos_w'])
            center_y = int(item['pos_h'])
            cv2.circle(he_img2, (center_x, center_y), radius, [255,255,0], -1)
            if index == 100:
                break
        img_show("he", he_img2)
        pass

    def draw_level_supspot_on_roi_he(self, level_dir, roi_mask):
        pos_file = f"{level_dir}/barcodes_pos.tsv.gz"
        df = pd.read_csv(pos_file, compression='gzip', sep='\t', names=['name', 'pos_w', 'pos_h'])
        print(df.shape)

        df['pos_w'] = df['pos_w'] * self.std_chip_zoom
        df['pos_h'] = df['pos_h'] * self.std_chip_zoom
        radius = int(self.slide_height * 0.7)

        he_img2 = copy.deepcopy(self.he_img)
        for index, item in df.iterrows():
            center_x = int(item['pos_w'])
            center_y = int(item['pos_h'])
            if center_x < 0 or center_x >= self.he_width:
                continue
            if center_y < 0 or center_y >= self.he_height:
                continue
            if roi_mask[center_y,center_x] > 0:
                cv2.circle(he_img2, (center_x, center_y), radius, [255, 255, 0], -1)
        img_show("he", he_img2)
        pass

    def read_roi_group_f_file(self, infile):
        with open(infile, 'r') as fp:
            load_dict = json.load(fp)
            roi_group = load_dict['ori_group']
        return roi_group
        pass

    def draw_roi_on_he_img(self, roi_group):
        he_img2 = copy.deepcopy(self.he_img)
        for roi in roi_group:
            if len(roi) <= 3:
                continue
            contours = np.array(roi, dtype=int)
            cv2.fillPoly(he_img2, [contours], (255, 0, 0))  # 填充内部
            # cv2.fillPoly(img,contours,(255,0,0)) #只染色边界
        img_show('img', he_img2)
        pass



if __name__ == "__main__":
    he_file = "D:/delete/smaSTViewer/chip5_level2_chip.tif"
    he_img = cv2.imread(he_file)
    sroi = SupspotROI(he_img, 13)

    json_file = 'D:/delete/smaSTViewer/project_chip5_test/roi_groups/roi_hello.json'
    roi_group = sroi.read_roi_group_f_file(json_file)

    # sroi.draw_roi_on_he_img(roi_group)
    # img_show("he", he_img)

    # sroi.draw_level_supspot_on_he('D:/delete/smaSTViewer/sma_data/level_13')

    roi_mask = sroi.cal_roi_group_mask(roi_group)
    # img_show('roi_mask', roi_mask)

    # sroi.draw_level_supspot_on_roi_he('D:/delete/smaSTViewer/sma_data/level_13',roi_mask)

    sroi.link_level_roi('D:/delete/smaSTViewer/sma_data/level_13',roi_mask,'D:/delete/smaSTViewer/sub_supspot')

    # 基因表达矩阵文件
    # level_dir = 'D:/delete/smaSTViewer/sma_data/level_13'
    # outdir = 'D:/delete/smaSTViewer/sub_supspot'
    # gene_matrix_file = f"{level_dir}/matrix.mtx.gz"
    # df = pd.read_csv(gene_matrix_file, compression='gzip', sep='\t', names=['gene', 'supspot', 'umi'], skiprows=3)
    # print("reading is ok")
    # new_gene_matrix_file = f"{outdir}/matrix.mtx.gz"
    # with gzip.open(new_gene_matrix_file, "wb") as fp_gzip:
    #     with io.TextIOWrapper(fp_gzip, encoding='utf-8') as fp:
    #         for index, item in df.iterrows():
    #             fp.write(f"{item['gene']}\t{item['supspot']}\t{item['umi']}\n")
    # print("gene exp matrix is ok")

    print("hello")

