from PIL import Image
Image.MAX_IMAGE_PIXELS = 3000000000
import cv2
import numpy as np
import matplotlib.pyplot as plt
import math
import gzip
import io

# 定义图片展示函数
ShowImageType = 1
def img_show(name, img):
    if ShowImageType == 0:
        cv2.imshow(name, img)
        cv2.waitKey(0)
        cv2.destroyAllWindows()
    else:
        plt.imshow(img)
        plt.title(name)
        plt.show()

class StdChipModel():
    def __init__(self, center_dist=4.0, side_len=13, zoom_coff=1.0):
        # init size
        self.center_dist = center_dist * zoom_coff
        self.row_height = self.center_dist * np.sqrt(3.0) / 2.0
        # init wh
        self.block_w = 46
        self.block_h = 46
        self.block_spot_w = 30
        self.block_spot_h = 35
        self.chip_spot_w = self.block_spot_w * self.block_w + (self.block_w-1)
        self.chip_spot_h = self.block_spot_h * self.block_h + (self.block_h-1)

        # set cutoff
        self.max_side_len = 19
        self.min_side_len = 1
        # init side len
        # 检查参数是否超出范围【2，15】
        if side_len < self.min_side_len or side_len > self.max_side_len:
            print(f"side length must be [{self.min_side_len}, {self.max_side_len}]")
            return None
        self.side_len = side_len

        # init superspots
        self.superspots = []
        self.superspots_next_checked = []
        self.center_coords = []
        # 初始化搜索状态
        self.is_search = np.zeros([self.chip_spot_h, self.chip_spot_w], dtype='uint8')
        pass

    def super_spot_cluster(self):
        # 生成第一个supspot
        supspot = self.gen_one_super_spot(0, 0)
        self.superspots.append(supspot)
        self.superspots_next_checked.append(0)
        center_coord = self.cal_center_coordinates(start_w=supspot[0][1], start_h=supspot[0][0])
        self.center_coords.append(center_coord)
        # 迭代supspot中的每个的6个相邻的supspot
        while(1):
            curr_len = len(self.superspots_next_checked)
            # print(f"sum:{sum(self.superspots_next_checked)},len:{curr_len}")
            if sum(self.superspots_next_checked) == curr_len:
                break
            for i in range(curr_len):
                if self.superspots_next_checked[i] == 1:
                    continue
                pass
                # 从当前supspot迭代其全部相邻的supspot
                # six_ang = self.six_angular_coordinates(start_w=self.superspots[i][0][1], start_h=self.superspots[i][0][0])
                six_ang = self.six_angular_coordinates(center_h=self.center_coords[i][0], center_w=self.center_coords[i][1])
                for side_i in range(6):
                    self.next_super_spot(side_i, six_ang)
                self.superspots_next_checked[i] = 1
                # print(f"coords:{self.center_coords}")
                # if i > 3:
                #     return None
        # return
        return self.superspots

    def gen_one_super_spot(self, start_w_i, start_h_i):
        supspot = []
        for i in range(self.side_len):
            h_i = start_h_i + i
            if h_i < 0 or h_i >self.chip_spot_h-1:
                continue
            if start_h_i % 2 == 0:
                curr_w_s = start_w_i - int(i/2)
            else:
                curr_w_s = start_w_i - int((i+1)/2)
            curr_w_e = curr_w_s + self.side_len + i
            for ss_i in range(curr_w_s, curr_w_e, 1):
                if ss_i < 0 or ss_i >self.chip_spot_w-1:
                    continue
                supspot.append([h_i,ss_i])
                if self.is_search[h_i,ss_i] > 0:
                    return None
                self.is_search[h_i,ss_i] = 1
        for i in range(self.side_len-1):
            h_i = start_h_i + self.side_len + i
            if h_i < 0 or h_i >self.chip_spot_h-1:
                continue
            if start_h_i % 2 == 0:
                curr_w_s = start_w_i - int((self.side_len-i-2)/2)
            else:
                curr_w_s = start_w_i - int((self.side_len-i-1)/2)
            curr_w_e = curr_w_s + self.side_len + self.side_len - i - 2
            for ss_i in range(curr_w_s, curr_w_e, 1):
                if ss_i < 0 or ss_i >self.chip_spot_w-1:
                    continue
                supspot.append([h_i, ss_i])
                if self.is_search[h_i,ss_i] > 0:
                    return None
                self.is_search[h_i, ss_i] = 1
        return supspot

    def get_next_pos(self, side_i, six_ang):
        if side_i == 0:
            next_h = six_ang[0][0] - (self.side_len*2-1)
            next_w = six_ang[0][1] - (six_ang[0][0] % 2)
        elif side_i == 1:
            next_h = six_ang[0][0] - self.side_len
            next_w = six_ang[2][1] + next_h%2
        elif side_i == 2:
            next_h = six_ang[2][0]
            next_w = six_ang[2][1]+1
        elif side_i == 3:
            next_h = six_ang[0][0] + (self.side_len * 2 - 1)
            next_w = six_ang[0][1] - (six_ang[0][0] % 2) + 1
        elif side_i == 4:
            next_h = six_ang[0][0] + self.side_len
            next_w = six_ang[5][1]-self.side_len + next_h%2
        else:
            next_h = six_ang[0][0] - self.side_len + 1
            next_w = six_ang[5][1]-self.side_len
        # print(f"side_i={side_i}, h,w={next_h},{next_w}")
        return next_w,next_h

    def next_super_spot(self, side_i, six_ang):
        next_w, next_h = self.get_next_pos(side_i, six_ang)
        # print(f"next_w, next_h={next_h},{next_w}")
        # 检查是否已经出界
        # if next_w < 0 or next_w > self.chip_spot_w-1:
        #     return None
        # if next_h < 0 or next_h > self.chip_spot_h-1:
        #     return None
        if next_w >= 0 and next_w <= self.chip_spot_w-1 :
            if next_h >= 0 and next_h <= self.chip_spot_h - 1:
                if self.is_search[next_h, next_w] > 0:
                    return None
        # 检查是否已经被处理过了
        # if self.is_search[next_h,next_w] > 0:
        #     return None
        # gen curr supspot
        supspot = self.gen_one_super_spot(start_w_i=next_w, start_h_i=next_h)
        if supspot is None:
            return None
        if len(supspot) == 0:
            return None

        self.superspots.append(supspot)
        self.superspots_next_checked.append(0)
        # center_coord = self.cal_center_coordinates(start_w=supspot[0][1], start_h=supspot[0][0])
        center_coord = self.cal_center_coordinates(start_w=next_w, start_h=next_h)
        self.center_coords.append(center_coord)
        pass

    def six_angular_coordinates(self, center_h, center_w):
        #        0-------1
        #      /          \
        #    5/            \
        #     \            /2
        #      \          /
        #       4--------3
        # init
        ang_coord = [[0,0],[0,0],[0,0],[0,0],[0,0],[0,0]]
        # 0, 1
        pos0_w = center_w - math.ceil((self.side_len - 1) / 2.0)
        if self.side_len % 2 == 0:
            pos0_w = pos0_w + 1 - center_h%2
        ang_coord[0] = [center_h-self.side_len+1, pos0_w]
        ang_coord[1] = [center_h-self.side_len+1, pos0_w+self.side_len-1]
        # 2, 5
        ang_coord[5] = [center_h, center_w-self.side_len+1]
        ang_coord[2] = [center_h, center_w+self.side_len-1]
        # 3, 4
        ang_coord[4] = [center_h+self.side_len-1, pos0_w]
        ang_coord[3] = [center_h+self.side_len-1, pos0_w+self.side_len-1]
        # return
        return ang_coord
        pass
    # def six_angular_coordinates(self, start_w, start_h):
    #     #        0-------1
    #     #      /          \
    #     #    5/            \
    #     #     \            /2
    #     #      \          /
    #     #       4--------3
    #     # init
    #     ang_coord = [[0,0],[0,0],[0,0],[0,0],[0,0],[0,0]]
    #     # 0, 1
    #     ang_coord[0] = [start_h, start_w]
    #     ang_coord[1] = [start_h,start_w+self.side_len-1]
    #     # 2, 5
    #     h25 = start_h + self.side_len - 1
    #     if start_h % 2 == 0:
    #         curr_w_s = start_w - int((self.side_len-1) / 2)
    #     else:
    #         curr_w_s = start_w - int((self.side_len-1 + 1) / 2)
    #     curr_w_e = curr_w_s + 2*self.side_len - 1
    #     ang_coord[5] = [h25, curr_w_s]
    #     ang_coord[2] = [h25, curr_w_e-1]
    #     # 3, 4
    #     h34 = start_h + 2*self.side_len - 2
    #     ang_coord[4] = [h34, start_w]
    #     ang_coord[3] = [h34, start_w+self.side_len-1]
    #     # return
    #     return ang_coord
    #     pass

    def cal_center_coordinates(self, start_w, start_h):
        # 2, 5
        h25 = start_h + self.side_len - 1
        if start_h % 2 == 0:
            curr_w_s = start_w - int((self.side_len - 1) / 2)
        else:
            curr_w_s = start_w - int((self.side_len - 1 + 1) / 2)
        # return
        return [h25, curr_w_s+self.side_len-1]
        pass

    def gen_honeycomb_img(self, coff=0.65, file=None):
        img = self.gen_empty_img()
        if file is None:
            for center_coord in self.center_coords:
                self.gen_one_honeycomb_img(img, center_coord, coff=coff)
        else:
            curr_center_coords = self.load_center_coords_f_file(file=file)
            for center_coord in curr_center_coords:
                self.gen_one_honeycomb_img(img, center_coord, coff=coff)
        return img
        pass

    def gen_empty_img(self):
        img_w = math.ceil( (self.chip_spot_w + 1 ) * self.center_dist )
        img_h = math.ceil( (self.chip_spot_h + 1 ) * self.row_height )
        img = np.zeros([img_h, img_w], dtype=int)
        return img
        pass

    def gen_one_honeycomb_img(self, img, center_coord, coff=1.0):
        # 计算中心spot点
        c_pos = [(center_coord[1]+1-0.5*(center_coord[0]%2))*self.center_dist, (center_coord[0]+1)*self.row_height]
        # 计算6个顶点的坐标
        side_len_px = (self.side_len - 1) * self.center_dist * coff
        side_len_px_a = side_len_px / 2.0
        side_len_px_b = side_len_px * math.sqrt(3.0) / 2.0
        six_poss = []
        six_poss.append([c_pos[0]-side_len_px_a, c_pos[1]-side_len_px_b])
        six_poss.append([c_pos[0]+side_len_px_a, c_pos[1]-side_len_px_b])
        six_poss.append([c_pos[0]+side_len_px, c_pos[1]])
        six_poss.append([c_pos[0]+side_len_px_a, c_pos[1]+side_len_px_b])
        six_poss.append([c_pos[0]-side_len_px_a, c_pos[1]+side_len_px_b])
        six_poss.append([c_pos[0]-side_len_px, c_pos[1]])
        # 检测是否超出图片区域
        img_w, img_h = img.shape[1],img.shape[0]
        # print(f"img_h,img_w:{img_h},{img_w}")
        # for pos in six_poss:
            # if pos[0] < 0 or pos[0] > img_w:
            #     return
            # if pos[1] < 0 or pos[1] > img_h:
            #     return
            # pos[0] = max(0.0, pos[0])
            # pos[0] = min(img_w, pos[0])
            # pos[1] = max(0.0, pos[1])
            # pos[1] = min(img_h, pos[1])
        # 画正六边形
        triangle = np.array(six_poss, dtype=int)
        cv2.fillConvexPoly(img, triangle, 255)
        # print(f"img.shape:{img.shape}")
        pass

    @staticmethod
    def cal_superspot_point_num(side_len):
        if side_len == 1:
            return 1
        return StdChipModel.cal_superspot_point_num(side_len-1) + (side_len - 1) * 6

    def convert_cluster_matrix(self, supspots):
        cluster_matrix = np.zeros([self.chip_spot_h, self.chip_spot_w], dtype=int)
        cluster_count = 0
        for supspot in supspots:
            for point in supspot:
                cluster_matrix[point[0],point[1]] = cluster_count
            cluster_count += 1
        return cluster_matrix
        pass

    @staticmethod
    def cal_center_dist_by_img_width(img_width):
        return 1.0 * img_width / 46 / 31

    def write_center_coord_2_file(self, outfile, center_dist, prefix=None):
        row_height = center_dist * np.sqrt(3) / 2.0
        if prefix is None:
            prefix = f"L{self.side_len}"
        with gzip.open(outfile, "wb") as fp_gzip:
            with io.TextIOWrapper(fp_gzip, encoding='utf-8') as fp:
                count = 0
                for coord in self.center_coords:
                    c_pos = [(coord[1] + 1 - 0.5 * (coord[0] % 2)) * center_dist,
                             (coord[0] + 1) * row_height]
                    fp.write(f"{prefix}_{count}\t{c_pos[0]}\t{c_pos[1]}\n")
                    count += 1







if __name__ == "__main__":
    for i in range(2,15,1):
        num = StdChipModel.cal_superspot_point_num(i)
        print(f"side_len={i},num={num},spotnum={46*46*31*36/num}")

    exit()

    scm = StdChipModel(side_len=13)
    # scm.gen_one_super_spot(5,0,0)
    print("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx")
    # scm.gen_one_super_spot(5,0,1)
    supspots = scm.super_spot_cluster()
    # six_ang = scm.six_angular_coordinates(3,0,0)
    # print(six_ang)
    # print(supspots[0])
    # print(supspots[1])
    # print(supspots[2])
    img = scm.gen_honeycomb_img(coff=0.7)
    # print(np.max(img))
    # print(np.min(img))
    # print(img[0,0])
    img_show("img", img)



















