import numpy as np
import pandas as pd
import os
from GeneMatrix import smaSTGeneMatrix
from StdChipModel import StdChipModel
import gzip
import io

class DiffLevelsGeneMatrix():
    def __init__(self, data_dir):
        # self.levels = [13, 11, 9, 7, 5, 3]
        # self.levels = [2,1]
        self.levels = [13, 11, 9, 7, 5, 4,  3, 2, 1]
        # self.levels = [2]
        self.sgm = smaSTGeneMatrix()
        self.sgm.struct_f_dir(data_dir)

        self.sort_gene_matrix()
        pass

    def sort_gene_matrix(self):
        bc_num = self.sgm.bc_pos.shape[0]
        print(f"bc_num:{bc_num}")
        sort_matrix = []
        for i in range(bc_num):
            sort_matrix.append({})
        raw_exp_matrix = self.sgm.exp_matrix
        count = 0
        for tup in raw_exp_matrix.itertuples():
            sort_matrix[tup[2]-1][tup[1]-1] = tup[3]
            count += 1
            if count%100000 == 0:
                print(f"sort count={count}")
        self.sort_matrix = sort_matrix

    def struct_gene_matrix_by_cluster(self, cluster_num, gene_num, cluster_matrix):
        cluster_exp_matrix = []
        for i in range(cluster_num):
            cluster_exp_matrix.append({})

        count = 0
        print(f"len(self.sort_matrix)={len(self.sort_matrix)}")
        spot_hs = self.sgm.bc_pos['global_row_index']
        spot_ws = self.sgm.bc_pos['global_col_index']
        umi_total = 0
        for bc_index in range(len(self.sort_matrix)):
            spot = self.sort_matrix[bc_index]
            spot_h = spot_hs[bc_index]
            spot_w = spot_ws[bc_index]
            cluster_index = cluster_matrix[spot_h, spot_w]
            for gene_index in spot.keys():
                umi_total += spot[gene_index]
                if gene_index in cluster_exp_matrix[cluster_index].keys():
                    cluster_exp_matrix[cluster_index][gene_index] += spot[gene_index]
                else:
                    cluster_exp_matrix[cluster_index][gene_index] = spot[gene_index]
            count += 1
            if count % 10000 == 0:
                print(f"cluster count={count}")

        return umi_total, cluster_exp_matrix
        pass

    def bc_in_cluster(self, cluster_matrix):
        bcs_num = len(self.sort_matrix)
        bcs = np.zeros(bcs_num, dtype=int)
        clusters = np.zeros(bcs_num, dtype=int)

        spot_hs = self.sgm.bc_pos['global_row_index']
        spot_ws = self.sgm.bc_pos['global_col_index']
        for bc_index in range(bcs_num):
            spot_h = spot_hs[bc_index]
            spot_w = spot_ws[bc_index]
            bcs[bc_index] = bc_index + 1
            clusters[bc_index] = cluster_matrix[spot_h, spot_w] + 1

        df = pd.DataFrame()
        df['bc'] = bcs
        df['cluster'] = clusters
        return df
        pass
    def write_bc_cluster_2_file(self, outfile, df):
        content = df.to_csv(sep='\t', header=False, index=False, line_terminator='\n')
        content = content.encode(encoding='utf-8')
        with gzip.open(outfile, "wb") as fp_gzip:
            fp_gzip.write(content)

    def struct_levels_gene_matrix_2_dir(self, outdir):
        if not os.path.exists(outdir):
            os.makedirs(outdir)
        for i in self.levels:
            self.struct_one_level_gene_matrix(outdir, i)
        pass

    def struct_one_level_gene_matrix(self, outdir, level):
        print("struct cluster")
        scm = StdChipModel(side_len=level)
        supspots = scm.super_spot_cluster()
        cluster_matrix = scm.convert_cluster_matrix(supspots)

        print("struct cluster gene matrix")
        bc_cluster_num = len(supspots)
        gene_num = len(self.sgm.gene_list)
        umi_total, cluster_exp_matrix = self.struct_gene_matrix_by_cluster(bc_cluster_num, gene_num, cluster_matrix)
        print(f"umi_total:{umi_total}")

        bc_cluster_df = self.bc_in_cluster(cluster_matrix)

        # 统计cluster中的read数
        self.sgm.bc_list_read['cluster'] = bc_cluster_df['cluster']
        cluster_read_num = self.sgm.bc_list_read.groupby('cluster', as_index=False).agg({'read_count': 'sum'}).copy()
        bc_list_df = pd.DataFrame()
        bc_list_df['cluster'] = range(1,bc_cluster_num+1,1)
        cluster_read_num_sort = pd.merge(bc_list_df,cluster_read_num,how='left')
        cluster_read_num_sort.fillna(0, inplace=True)

        print("output")
        # output 2 file
        level_outdir = f"{outdir}/level_{level}"
        if not os.path.exists(level_outdir):
            os.makedirs(level_outdir)
        # file name
        exp_matrix_file = f"{level_outdir}/matrix.mtx.gz"
        bc_pos_file = f"{level_outdir}/barcodes_pos.tsv.gz"
        bc_list_file = f"{level_outdir}/barcodes.tsv.gz"
        bc_read_file = f"{level_outdir}/barcodes_read.tsv.gz"
        gene_list_file = f"{level_outdir}/features.tsv.gz"
        bc_cluster_file = f"{level_outdir}/barcodes_cluster.tsv.gz"

        # bc cluster
        print("output bc_cluster")
        self.write_bc_cluster_2_file(bc_cluster_file, bc_cluster_df)

        # bc pos
        print("output center_coord")
        center_dist = StdChipModel.cal_center_dist_by_img_width(1000)
        scm.write_center_coord_2_file(bc_pos_file, center_dist, prefix=f"L{scm.side_len}")
        # bc list
        print("output bc list")
        self.write_bc_list_2_file(bc_list_file,bc_cluster_num, prefix=f"L{scm.side_len}")
        self.write_bc_read_num_2_file(bc_read_file,bc_cluster_num, cluster_read_num_sort, prefix=f"L{scm.side_len}")

        # gene list
        print("output gene_list")
        self.write_gene_list_2_file(gene_list_file)

        # gene exp matrix
        print("output exp_matrix")
        self.sgm.write_exp_matrix_2_file(exp_matrix_file, cluster_exp_matrix, [gene_num, bc_cluster_num, umi_total])
        pass

    def write_bc_list_2_file(self, outfile, bc_num, prefix=None):
        if prefix is None:
            prefix = f"L{self.side_len}"
        with gzip.open(outfile, "wb") as fp_gzip:
            with io.TextIOWrapper(fp_gzip, encoding='utf-8') as fp:
        # with gzip.open(outfile, "wb") as fp:
                for count in range(bc_num):
                    fp.write(f"{prefix}_{count}\n")

    def write_bc_read_num_2_file(self, outfile, bc_num, read_num, prefix=None):
        if prefix is None:
            prefix = f"L{self.side_len}"
        with gzip.open(outfile, "wb") as fp_gzip:
            with io.TextIOWrapper(fp_gzip, encoding='utf-8') as fp:
        # with gzip.open(outfile, "wb") as fp:
                for count in range(bc_num):
                    fp.write(f"{prefix}_{count}\t{read_num.iloc[count,1]}\n")


    pass
    def write_gene_list_2_file(self, outfile):
        with gzip.open(outfile, "wb") as fp_gzip:
            with io.TextIOWrapper(fp_gzip, encoding='utf-8') as fp:
        # with gzip.open(outfile, "wb") as fp:
                count = 0
                for tup in self.sgm.gene_list.itertuples():
                    fp.write(f"{tup[1]}\t{tup[2]}\t{tup[3]}\n")
                    count += 1



if __name__ == "__main__":
    # data_dir = 'D:/delete/smaSTViewer/data/'
    # dlgm = DiffLevelsGeneMatrix(data_dir)
    #
    # outdir = 'D:/delete/smaSTViewer/sma_data/'
    # dlgm.struct_levels_gene_matrix_2_dir(outdir)

    # data_dir = 'D:/scst/st_Brain/20220317_Brain/'
    data_dir = 'D:/scst/st_chen_JM1_3/JM1-3/'
    dlgm = DiffLevelsGeneMatrix(data_dir)

    # outdir = 'D:/delete/smaSTViewer/Brain_level_matrix_new/'
    outdir = 'D:/delete/smaSTViewer/N6_level_matrix_new3/'
    dlgm.struct_levels_gene_matrix_2_dir(outdir)


