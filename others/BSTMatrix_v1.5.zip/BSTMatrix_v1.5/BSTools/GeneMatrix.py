import numpy as np
import pandas as pd
import os
import gzip
import io

class smaSTGeneMatrix():
    def __init__(self):
        self.bc_list = None
        self.gene_list = None
        self.exp_matrix = None
        self.bc_pos = None
        self.bc_list_read = None
        pass

    def struct_f_dir(self, data_dir):
        bc_list_file = f"{data_dir}/barcode.tsv"
        gene_list_file = f"{data_dir}/features.tsv"
        exp_matrix_file = f"{data_dir}/matrix.tsv"
        bc_pos_file = f"{data_dir}/barcode_pos.tsv"
        bc_read_file = f"{data_dir}/bc_umi_read.tsv.gz"
        self.update_bc_list_f_file(bc_list_file)
        self.update_gene_list_f_file(gene_list_file)
        self.update_exp_matrix_f_file(exp_matrix_file)
        self.update_bc_pos_f_file(bc_pos_file, pos_type=0)
        self.update_bc_read_f_file(bc_read_file)
        pass

    def update_bc_read_f_file(self, infile):
        self.bc_read = pd.read_csv(infile, compression='gzip', sep='\t', names=['bc_name', 'umi_seq', 'read_count'], header=None)
        read_num = self.bc_read.groupby('bc_name', as_index=False).agg({'read_count': 'sum'}).copy()
        total_read = read_num['read_count'].sum()
        self.bc_list_read = pd.merge(self.bc_list, read_num, how='left')
        chip_read = self.bc_list_read['read_count'].sum()
        print(f"total_read:{total_read}, chip_read:{chip_read}, chip_rate:{chip_read/total_read}")
        pass

    def update_bc_list_f_file(self, infile):
        self.bc_list = pd.read_csv(infile, header=None, sep='\t', names=['bc_name'])
        pass

    def update_gene_list_f_file(self, infile):
        self.gene_list = pd.read_csv(infile, header=None, sep='\t', names=['db_id', 'abbreviation', 'notes'])
        pass

    def update_exp_matrix_f_file(self, infile, skiprows=3):
        self.exp_matrix = pd.read_csv(infile, header=None, sep='\t', names=['gene_index', 'bc_index', 'umi_count'], skiprows=skiprows)
        pass

    def update_bc_pos_f_file(self, infile, pos_type=0):
        if pos_type == 0:
            col_names = ['bc_name','subarea_col_index', 'subarea_row_index', 'col_index', 'row_index']
            # temp_bc_pos = pd.read_csv(infile, header=None, sep='\t', names=col_names, nrows=100000)
            temp_bc_pos = pd.read_csv(infile, header=None, sep='\t', names=col_names)
            self.chip_pos_convert(temp_bc_pos)
            self.bc_pos = temp_bc_pos

        else:
            col_names = ['bc_name', 'global_row_index', 'global_col_index']
            self.bc_pos = pd.read_csv(infile, header=None, sep='\t', names=col_names)
        pass


    def chip_pos_convert(self, poss):
        print(f"df.shape[0]={poss.shape[0]}")
        # poss['global_row_index'] = poss[['subarea_row_index','row_index']].apply(lambda x:x['subarea_row_index']*36+x['row_index'], axis=1)
        # poss['global_col_index'] = poss[['subarea_col_index','col_index']].apply(lambda x:x['subarea_col_index']*36+x['col_index'], axis=1)
        g_row_index = np.zeros(poss.shape[0], dtype=int)
        g_col_index = np.zeros(poss.shape[0], dtype=int)
        count = 0
        for tup in poss.itertuples():
            # g_row_index[count] = tup[3]*36+tup[5]
            # g_col_index[count] = tup[2]*31+tup[4]
            g_row_index[count] = tup[2] * 36 + tup[4]
            g_col_index[count] = tup[3] * 31 + tup[5]
            count += 1
            if count%100000 == 0:
                print(f"count={count}")
        poss['global_row_index'] = g_row_index
        poss['global_col_index'] = g_col_index
        pass


    def struct_gene_matrix_by_cluster(self, cluster_num, cluster_matrix=None):
        cluster_exp_matrix = []
        for i in range(cluster_num):
            cluster_exp_matrix.append({})

        raw_exp_matrix = self.exp_matrix
        count = 0
        for tup in raw_exp_matrix.itertuples():
            gene_index = tup[1]
            bc_index = tup[2]
            umi_count = tup[3]
            # bc = self.bc_pos[count:(count+1)]
            spot_h = self.bc_pos.loc[bc_index][5]
            spot_w = self.bc_pos.loc[bc_index][6]
            # print(f"bc:{bc},h,w={spot_h},{spot_w}")
            # print(tup[0], '-->', tup[1:], type(tup[1:]))
            # print(tup[2]+1000000)
            # print(cluster_matrix[spot_h,spot_w])
            cluster_index = cluster_matrix[spot_h,spot_w]
            if gene_index in cluster_exp_matrix[cluster_index].keys():
                cluster_exp_matrix[cluster_index][gene_index] += umi_count
            else:
                cluster_exp_matrix[cluster_index][gene_index] = umi_count
            count += 1
            if count%100000==0:
                print(f"count={count}")
            # if count >80000:
            #     break
        return cluster_exp_matrix
        pass

    def write_bc_list_2_file(self, outfile, bc_len, prefix):
        with open(outfile, "w") as fp:
            for i in range(bc_len):
                fp.write(f"{prefix}_{i}\n")
    pass
    def write_gene_list_2_file(self, outfile):
        with open(outfile, "w") as fp:
            for tup in self.gene_list.itertuples():
                fp.write(f"{tup[1]}\t{tup[2]}\t{tup[3]}\n")
    pass
    def write_exp_matrix_2_file(self, outfile, cluster_exp_matrix, matrix_info):
        # 构建基因表达矩阵
        gene_indexs = []
        bc_indexs = []
        umi_counts = []
        for bc_index in range(len(cluster_exp_matrix)):
            cluster = cluster_exp_matrix[bc_index]
            if len(cluster) == 0:
                continue
            for gene_index in cluster.keys():
                umi_count = cluster[gene_index]
                gene_indexs.append(gene_index+1)
                bc_indexs.append(bc_index+1)
                umi_counts.append(umi_count)
        df = pd.DataFrame()
        df['gene_index'] = gene_indexs
        df['bc_index'] = bc_indexs
        df['umi_count'] = umi_counts
        # write to gzip file
        content = df.to_csv(sep='\t', header=False, index=False, line_terminator='\n')
        content = f"%%MatrixMarket matrix coordinate real general\n%\n{matrix_info[0]}\t{matrix_info[1]}\t{df.shape[0]}\n" + content
        content = content.encode()
        with gzip.open(outfile, "wb") as fp_gzip:
            fp_gzip.write(content)
        print("gene exp matrix is ok")
        print(f"row num={df.shape[0]}, umi total={matrix_info[2]}")

        # with gzip.open(outfile, "wb") as fp_gzip:
        #     with io.TextIOWrapper(fp_gzip, encoding='utf-8') as fp:
        # # with gzip.open(outfile, "wb") as fp:
        #         fp.write('%%MatrixMarket matrix coordinate real general\n')
        #         fp.write('%\n')
        #         fp.write(f"{matrix_info[0]}\t{matrix_info[1]}\t{matrix_info[2]}\n")
        #         for bc_index in range(len(cluster_exp_matrix)):
        #             cluster = cluster_exp_matrix[bc_index]
        #             if len(cluster) == 0:
        #                 continue
        #             for gene_index in cluster.keys():
        #                 umi_count = cluster[gene_index]
        #                 fp.write(f"{gene_index+1}\t{bc_index+1}\t{umi_count}\n")

    # def write_exp_matrix_2_dir(self, cluster_exp_matrix, outdir, scm):
    #     if not os.path.exists(outdir):
    #         os.makedirs(outdir)
    #     # file name
    #     bc_list_file = f"{outdir}/barcode.csv"
    #     gene_list_file = f"{outdir}/features.csv"
    #     exp_matrix_file = f"{outdir}/matrix.csv"
    #     bc_pos_file = f"{outdir}/barcode_pos.csv"
    #
    #     # bc list and bc pos
    #     # bc list
    #     self.write_bc_list_2_file(bc_list_file, len(cluster_exp_matrix), f"L{scm.side_len}")
    #     # bc pos
    #     center_dist = StdChipModel.cal_center_dist_by_img_width(1000)
    #     scm.write_center_coord_2_file(bc_pos_file,center_dist, prefix=f"L{scm.side_len}")
    #
    #     # gene list
    #     self.write_gene_list_2_file(gene_list_file)
    #
    #     # gene exp matrix
    #     self.write_exp_matrix_2_file(exp_matrix_file, cluster_exp_matrix)
    #     pass








if __name__ == "__main__":
    bc_pos_file = 'D:/delete/smaSTViewer/data/barcode_pos.tsv'
    sgm = smaSTGeneMatrix()
    sgm.update_bc_pos_f_file(bc_pos_file)

    # bc_list_file = f"D:/delete/smaSTViewer/data/barcode.tsv"
    # sgm.update_bc_list_f_file(bc_list_file)
    # print(f"df.shape[0]:{sgm.bc_list.shape[0]}")

    exp_matrix_file = 'D:/delete/smaSTViewer/data/matrix.tsv'
    sgm.update_exp_matrix_f_file(exp_matrix_file)
    print(f"df.shape[0]:{sgm.exp_matrix.shape[0]}")

    # gene list
    gene_list_file = 'D:/delete/smaSTViewer/data/features.tsv'
    sgm.update_gene_list_f_file(gene_list_file)



    from StdChipModel import StdChipModel

    print("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx")
    scm = StdChipModel(side_len=13)
    supspots = scm.super_spot_cluster()
    cluster_matrix = scm.convert_cluster_matrix(supspots)

    bc_cluster_num = len(supspots)
    cluster_exp_matrix = sgm.struct_gene_matrix_by_cluster(bc_cluster_num, cluster_matrix)

    sgm.write_exp_matrix_2_dir(cluster_exp_matrix, 'D:/delete/smaSTViewer/data_l13/', scm)
    pass







