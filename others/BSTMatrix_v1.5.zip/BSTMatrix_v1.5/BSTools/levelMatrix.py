import gzip
import getopt
import sys
from DiffLevelsGeneMatrix import DiffLevelsGeneMatrix
import os


def usage():
    print("======="*10)
    print("Usage:")
    print("1) python levelMatrix.py -i d:/testdir/ -o d:/outdir/")
    print("2) python levelMatrix.py --indir d:/testdir/ --outdir d:/outdir/")
    print("3) python levelMatrix.py -i d:/testdir/ -o d:/outdir/ -L 13,11,9,7,5,4,3,2,1")
    print("4) python levelMatrix.py --indir d:/testdir/ --outdir d:/outdir/ --levels 13,11,9,7,5,4,3,2,1")
    print("5) python levelMatrix.py -h")
    print("6) python levelMatrix.py --help")
    print("======="*10)
    exit()


def main():
    options, args = getopt.getopt(sys.argv[1:], 'hi:o:L:', ['help', 'indir=', 'outdir=', 'levels='])

    # init
    indir = None
    outdir = None
    levels = None

    options_dict = {}
    for name, value in options:
        if name not in options_dict.keys():
            options_dict[name] = value

    if '-h' in options_dict.keys() or '--help' in options_dict.keys():
        usage()

    if '-i' not in options_dict.keys() and '--indir' not in options_dict.keys():
        print("-i or --indir must exist")
        usage()

    if '-o' not in options_dict.keys() and '--outdir' not in options_dict.keys():
        print("-o or --outdir must exist")

    if '-i' in options_dict.keys():
        indir = options_dict['-i']
    if '--indir' in options_dict.keys():
        indir = options_dict['--indir']

    if '-o' in options_dict.keys():
        outdir = options_dict['-o']
    if '--outdir' in options_dict.keys():
        outdir = options_dict['--outdir']

    if '-L' in options_dict.keys():
        levels = options_dict['-L'].split(',')
    if '--levels' in options_dict.keys():
        levels = options_dict['--levels'].split(',')
    if levels is not None:
        levels = list(map(lambda x: int(x), levels))

    print(f"indir={indir}, outdir={outdir}, options={options_dict}, levels={levels}")

    if not os.path.exists(outdir):
        os.makedirs(outdir)

    dlgm = DiffLevelsGeneMatrix(indir)
    if levels is not None:
        dlgm.levels = levels
    dlgm.struct_levels_gene_matrix_2_dir(outdir)


if __name__ == "__main__":
    main()


