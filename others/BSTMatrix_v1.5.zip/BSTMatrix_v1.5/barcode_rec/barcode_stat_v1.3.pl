#!/usr/bin/perl -w
use strict ;

if (@ARGV != 3){
    print "perl $0 fafile infile outfile\n" ;
    exit(1) ;
}

my ($fafile, $infile, $outfile) = @ARGV ;

my %hseq = ();
if ($fafile =~ m/\.fa$|\.fasta$/i){
    open (IN, $fafile) || die "$fafile, $!\n" ;
    $/ = ">" ;
    while(<IN>){
        chomp ;
        next if (m/^\s*$/) ;
        my ($id, $seq) = split /\n/, $_, 2 ;
        $seq =~ s/\n//g ;
        $hseq{$id} = $seq ;
    }
    $/ = "\n" ;
    close(IN);
}
elsif($fafile =~ m/\.fq$|\.fastq$/i){
    open (IN, $fafile) || die "$fafile, $!\n" ;
    while(<IN>){
        my $id = $_ ;
        my $seq = <IN> ;
        my $id2 = <IN> ;
        my $qual = <IN> ;
        chomp($id, $seq, $id2, $qual);
        $id = (split /\s+/, $id)[0] ;
        $id =~ s/^\@// ;
        $seq =~ s/\n//g ;
        $hseq{$id} = $seq ;
    }
    close(IN);
}
else{
    print "reads file must be end with \".fq, .fastq, .fa, .fasta\": $fafile\n" ;
    exit(1);
}

my $umi_len = 12 ;
my %humi_pos = (
    'bc1' => 81,
    'bc2' => 44,
    'bc3' => 19,
);
my %href_pos = (
	'bc1'   => 0 ,
	'link1' => 17 ,
	'bc2'   => 37 ,
	'bc3'   => 62 ,
);

open (IN, $infile) || die "$infile, $!\n" ;
my %hbc = ();
my %hbc_umi = ();
my %hsingle = ();
my %hbc_stat = ();
my $total = 0 ;
open (OUT, ">$outfile.umi") || die "$outfile.umi, $!\n" ;
while(<IN>){
    chomp ;
    my ($id, $type, $posi) = split ;
    $total++ ;
    next if ($type =~ /null/i);
    if ($type =~ m/bc1/ && $type =~ m/bc2/ && $type =~ m/bc3/){
        $hbc{$type}++ ;
    }
    my @poses = split /\-/, $posi ;
    my @types = split /\-/, $type ;
    my @bcs = ();
    my $umi_seq = "" ;
    for (my $i=0; $i<@types; $i++){
        if ($types[$i] =~ m/(bc\d)\_\d+/){
            $hsingle{$1}++ ;
            push @bcs, $1 ;
            my ($ref_pos, $map_pos) = split /,/, $poses[$i] ;
            my $umi_pos = $humi_pos{$1} + ($map_pos - $ref_pos) + $href_pos{$1} ;
            $umi_seq = substr($hseq{$id}, $umi_pos, $umi_len);
        }
    }
    my $bc_type = join('-', @bcs) ;
    $hbc_stat{$bc_type}++ ;

    $hbc_umi{$type}{$umi_seq}++ ;
    print OUT "$id\t$type\t$posi\t$umi_seq\n" ;
}
close(OUT);
close(IN);

open (OUT, ">$outfile.full_stat") || die "$outfile.full_stat, $!\n" ;
#print OUT "#Type\tReadsNum\tPercent(%)\n" ;
print OUT "#Type\tReadsNum\tUMI\n" ;
for my $type (sort {$hbc{$b}<=>$hbc{$a}} keys %hbc){
    #my $rate = int(($hbc{$type}/$total)*10000)/100 ;
    my $umi = scalar(keys %{$hbc_umi{$type}}) ;
    print OUT "$type\t", $hbc{$type}, "\t", $umi, "\n" ;
}
close(OUT);

open (OUT, ">$outfile.bc_stat") || die "$outfile.bc_stat, $!\n" ;
print OUT "#Type\tReadsNum\tPercent(%)\n" ;
for my $type (sort keys %hbc_stat){
    my $num = $hbc_stat{$type} ;
    my $rate = int(($num/$total)*10000)/100 ;
    print OUT "$type\t$num\t$rate\n" ;
}
print OUT "========= single stat =========\n" ;
for my $type (sort keys %hsingle){
    my $num = $hsingle{$type} ;
    my $rate = int(($num/$total)*10000)/100 ;
    print OUT "$type\t$num\t$rate\n" ;
}
close(OUT) ;

