#!/usr/bin/perl -w
use strict ;

if (@ARGV < 3){
    print "v1.2: change position info\n" ;
    print "v1.3: change sort position\n" ;
	print "Usage:\n\tperl $0 infafile kmerfile outfile [kmer:9]\n" ;
	exit(1);
}

my ($fafile, $kmerfile, $outfile, $kmerlen) = @ARGV ;
$kmerlen ||= 9 ;

my %hkmer = ();
my %hpos = ();
&get_kmer($kmerfile, \%hkmer, \%hpos);

&read_fa_and_check_barcode($fafile, $outfile, \%hkmer, \%hpos, $kmerlen);



#&get_kmer($kmerfile, \%hkmer, \%hpos);
sub get_kmer()
{
	my ($kmerfile, $ahkmer, $ahpos) = @_ ;

	open (IN, $kmerfile) || die "$kmerfile, $!\n" ;
	while(<IN>){
		chomp ;
		next if (m/^\s*$|^\#/);
		my ($kmer, $num, @ids) = split ;
		if ($num == 1){
			$ahkmer->{$kmer} = $ids[0] ;
			$ahpos->{$kmer} = $ids[1] ;
		}
	}
	close(IN);

	return ;
}

#&read_fa_and_check_barcode($fafile, $outfile, \%hkmer, \%hpos, $kmerlen);
sub read_fa_and_check_barcode()
{
	my ($fafile, $outfile, $ahkmer, $ahpos, $kmerlen) = @_ ;

	open (IN, $fafile) || die "$fafile, $!\n" ;
	open (OUT, ">$outfile") || die "$outfile, $!\n" ;
    $/ = ">" ;
	while(<IN>){
        chomp ;
        next if (m/^\s*$/);
        my ($id, $seq) = split /\n/, $_, 2 ;
		$id = (split /\s+/, $id)[0] ;
		$seq =~ s/\n//g ;
		my $len = length($seq) ;
		my %htypes = ();
		my %hkmer_ref = ();
		for (my $i=0; $i<$len-$kmerlen+1; $i++){
			my $kmer = substr($seq, $i, $kmerlen);
			if (defined $ahkmer->{$kmer}){
				$htypes{$ahkmer->{$kmer}}++ ;
                push @{$hkmer_ref{$ahkmer->{$kmer}}}, [$ahpos->{$kmer}, $i] ;
			}
		}
		print OUT "$id" ;
		for my $key (sort {$htypes{$b}<=>$htypes{$a}} keys %htypes){
            my @poses = sort {$a->[1]<=>$b->[1]} @{$hkmer_ref{$key}} ;
            my @ref_pos = ();
            my @kmer_pos = ();
            for (my $i=0; $i<@poses; $i++){
                push @ref_pos, $poses[$i][0] ;
                push @kmer_pos, $poses[$i][1] ;
            }
			print OUT " $key:", $htypes{$key}, ":", join(',', @ref_pos) ,":", join(',', @kmer_pos) ;
		}
		print OUT "\n" ;
	}
    $/ = "\n" ;
	close(IN);
	close(OUT);

	return ;
}

