#!/usr/bin/perl -w
# 
# Copyright (c) BIO_MARK 2021
# Writer:         Dengdj <dengdj@biomarker.com.cn>
# Program Date:   2021
# Modifier:       Dengdj <dengdj@biomarker.com.cn>
# Last Modified:  2021
my $ver="1.3";

use strict;
use Getopt::Long;
use Data::Dumper;
use FindBin qw($Bin $Script);
use File::Basename qw(basename dirname);

#####################

my %opts;
GetOptions(\%opts,"i=s","o=s","m=s","s=s","h" );

#&help()if(defined $opts{h});
if(!defined($opts{i}) || !defined($opts{o}) || defined($opts{h}))
{
	print <<"	Usage End.";
	Description:
		
		Version: $ver
		v1.2   : add max offset for kmer map position vs ref kmer position, default <= 5 [-s]
		v1.3   : filter mult-bc reads type(like: bc1-bc2-bc2-bc3...).

	Usage:

		-i           barcode judge file                      <infile>     must be given
		-o           result file                             <outfile>    must be given
		-m           min kmer number                         [int]        optional[3]  
		-s           max offset number                       [int]        optional[5]  
		-h           Help document

	Usage End.

	exit;
}

###############Time
my $Time_Start;
$Time_Start = sub_format_datetime(localtime(time()));
&show_log("Start Time :[$Time_Start]");
################
$| = 1 ;
## get parameters
my $judgefile = $opts{i} ;
my $outfile = $opts{o} ;
my $minkmer = defined $opts{m} ? $opts{m} : 3 ;
my $max_offset = defined $opts{s} ? $opts{s} : 5 ;

my %hpos = (
	'bc1'   => 1 ,
	'bc2'   => 23 ,
	'bc3'   => 48 ,
);

my %hlen = (
	'bc1'   => 17 ,
	'bc2'   => 19 ,
	'bc3'   => 19 ,
);

## process
&reading_judge_file_and_get_type($judgefile, $outfile, $minkmer, \%hpos, \%hlen);

###############Time
my $Time_End;
$Time_End = sub_format_datetime(localtime(time()));
&show_log("End Time :[$Time_End]");

###############Subs
sub sub_format_datetime {#Time calculation subroutine
    my($sec, $min, $hour, $day, $mon, $year, $wday, $yday, $isdst) = @_;
	$wday = $yday = $isdst = 0;
    sprintf("%4d-%02d-%02d %02d:%02d:%02d", $year+1900, $mon+1, $day, $hour, $min, $sec);
}

sub ABSOLUTE_DIR
{ #$pavfile=&ABSOLUTE_DIR($pavfile);
	my $cur_dir=`pwd`;
	$cur_dir =~ s/\n$//;
	my ($in)=@_;
	my $return="";
	
	if(-f $in)
	{
		my $dir=dirname($in);
		my $file=basename($in);
		chdir $dir;$dir=`pwd`;
		$dir =~ s/\n$// ;
		$return="$dir/$file";
	}
	elsif(-d $in)
	{
		chdir $in;$return=`pwd`;
		$return =~ s/\n$// ;
	}
	else
	{
		warn "Warning just for file and dir [$in]\n";
		exit;
	}
	
	chdir $cur_dir;
	return $return;
}

# &show_log("txt")
sub show_log()
{
	my ($txt) = @_ ;
	my $time = time();
	my $Time = &sub_format_datetime(localtime($time));
	print "$Time:\t$txt\n" ;
	return ($time) ;
}

#&run_or_die($cmd);
sub run_or_die()
{
	my ($cmd) = @_ ;
	my $start_time = &show_log($cmd);
	my $flag = system($cmd) ;
	if ($flag != 0){
		my $end_time = &show_log("Error: command fail: $cmd");
		&show_log("Elaseped time: ".($end_time - $start_time)."s\n");
		exit(1);
	}
	my $end_time = &show_log("done.");
	&show_log("Elaseped time: ".($end_time - $start_time)."s\n");
	return ;
}

## qsub
sub qsub()
{
	my ($shfile, $maxproc) = @_ ;
	my $dir = dirname($shfile) ;
	my $cmd = "cd $dir && sh /share/nas2/genome/bmksoft/tool/qsub_sge_plus/v1.0/qsub_sge.plus.sh --maxproc $maxproc --reqsub --independent $shfile" ;
	&run_or_die($cmd);

	return ;
}

## qsub_mult($shfile, $max_proc, $job_num)
sub qsub_mult()
{
	my ($shfile, $max_proc, $job_num) = @_ ;
	if ($job_num > 500){
		my @shfiles = &cut_shfile($shfile);
		for my $file (@shfiles){
			&qsub($file, $max_proc);
		}
	}
	else{
		&qsub($shfile, $max_proc) ;
	}
}

#my @shfiles = &cut_shfile($shfile);
sub cut_shfile()
{
	my ($file) = @_ ;
	my @files = ();
	my $num = 0 ;
	open (IN, $file) || die "Can't open $file, $!\n" ;
	(my $outprefix = $file) =~ s/.sh$// ;
	while (<IN>){
		chomp ;
		if ($num % 500 == 0){
			close(OUT);
			my $outfile = "$outprefix.sub_".(int($num/500)+1).".sh" ;
			push @files, $outfile ;
			open (OUT, ">$outfile") || die "Can't creat $outfile, $!\n" ;
		}
		print OUT $_, "\n" ;
		$num ++ ;
	}
	close(IN);
	close(OUT);

	return @files ;
}

#my ($index, $last_ref_pos, $last_map_pos) = &get_best_bc($hbc{$bc}, $ahpos, $ahlen, $minkmer);
sub get_best_bc()
{
    my ($abcs, $ahpos, $ahlen, $minkmer) = @_ ;

    my $max_index = '' ;
    my $max_match = 0 ;
    my $max_last_ref_pos = 0 ;
    my $max_last_map_pos = 0 ;
    my $mult_flag = 0 ;
    for (my $i=0; $i<@{$abcs}; $i++){
        my ($index, $num, $ref_pos, $map_pos) = @{$abcs->[$i]} ;
        #print "$index\t$num\t$ref_pos\t$map_pos\n" ;
        my @ref_poses = split /\,/, $ref_pos ;
        my @map_poses = split /\,/, $map_pos ;
        my $match = 0 ;
        my $last_ref_pos = 0 ;
        my $last_map_pos = 0 ;
        for (my $j=0; $j<@ref_poses; $j++){
            my $offset = abs($ref_poses[$j] - $map_poses[$j]) ;
            if ($offset > $max_offset){
                next ;
            }
            else{
                $match++ ;
                $last_ref_pos = $ref_poses[$j] ;
                $last_map_pos = $map_poses[$j] ;
            }
        }
        if ($match > $max_match){
            $max_match = $match ;
            $max_index = $index ;
            $max_last_ref_pos = $last_ref_pos ;
            $max_last_map_pos = $last_map_pos ;
            $mult_flag = &judge_mult_bc(\@ref_poses, \@map_poses, $minkmer);
        }
    }

    return($max_index, $max_last_ref_pos, $max_last_map_pos, $mult_flag);
}

#&reading_judge_file_and_get_type($judgefile, $outfile, $minkmer, \%hpos, \%hlen);
sub reading_judge_file_and_get_type()
{
    my ($infile, $outfile, $minkmer, $ahpos, $ahlen) = @_ ;

    open (IN, $infile) || die "$infile, $!\n" ;
    open (OUT, ">$outfile") || die "$outfile, $!\n" ;
    my $part = 0 ;
    my $null = 0 ;
    my $full = 0 ;
    my $sum = 0 ;
    my $mult = 0 ;
    my %hstat = ();
    while(<IN>){
        chomp ;
        next if (m/^\#|^\s*$/);
        my ($id, @infos) = split ;
        my %hbc = ();
        for (my $i=0; $i<@infos; $i++){
            if ($infos[$i] =~ m/(bc\d)\_(\d+)\:(\d+)\:(.*?)\:(.*)/){
                my ($bc, $index, $num, $ref_pos, $map_pos) = ($1, $2, $3, $4, $5);
                next if ($num < $minkmer) ;
                push @{$hbc{$bc}}, [$index, $num, $ref_pos, $map_pos] ;
            }
        }
        my @types = ();
        my @pos = ();
        my $flag = 0 ;
        my $mult_flag = 0 ;
        for my $bc (qw/bc1 bc2 bc3/){
            if (!defined $hbc{$bc}){
                $flag = 1 ;
                next ;
            }
            if (scalar @{$hbc{$bc}} == 1){
                my ($index, $num, $ref_pos, $map_pos) = @{$hbc{$bc}[0]} ;
                my @ref_poses = split /\,/, $ref_pos ;
                my @map_poses = split /\,/, $map_pos ;
                my $flag = &judge_mult_bc(\@ref_poses, \@map_poses, $minkmer);
                $mult_flag = 1 if ($flag == 1);
                my $match = 0 ;
                my $last_ref_pos = 0 ;
                my $last_map_pos = 0 ;
                for (my $i=0; $i<@ref_poses; $i++){
                    my $offset = abs($ref_poses[$i] - $map_poses[$i]) ;
                    if ($offset > $max_offset){
                        next ;
                    }
                    else{
                        $match++ ;
                        $last_ref_pos = $ref_poses[$i] ;
                        $last_map_pos = $map_poses[$i] ;
                    }
                }
                if ($match >= $minkmer){
                    if ($mult_flag == 1){
                        push @types, "$bc\_".$hbc{$bc}[0][0] ;
                        push @pos, $ref_poses[-1].",".$map_poses[-1] ;
                    }
                    else{
                        push @types, "$bc\_".$hbc{$bc}[0][0] ;
                        push @pos, "$last_ref_pos,$last_map_pos" ;
                    }
                }
            }
            else{
                my ($index, $last_ref_pos, $last_map_pos, $flag) = &get_best_bc($hbc{$bc}, $ahpos, $ahlen, $minkmer);
                next if ($index eq '');
                push @types, "$bc\_$index" ;
                push @pos, "$last_ref_pos,$last_map_pos" ;
                $mult_flag = 1 if ($flag == 1);
            }
        }
        $sum++ ;
        if ($mult_flag == 1){
            my $type = join("-", @types);
            my $posi = join("-", @pos);
            print OUT "$id\tNull-mult\t$type\t$posi\n" ;
            $mult++ ;
        }
        elsif (scalar @types == 0){
            print OUT "$id\tNull\n" ;
            $null++ ;
        }
        else{
            my $type = join("-", @types);
            my $posi = join("-", @pos);
            print OUT "$id\t$type\t$posi\n" ;
            if ($flag == 1){
                $part++ ;
            }
            else{
                $full++ ;
                $hstat{$type}++ ;
            }
        }
    }
    close(IN);
    close(OUT);
    open (ST, ">$outfile.stat") || die "$outfile.stat, $!\n" ;
    print ST "SUM\t$sum\t100\n" ;
    print ST "Full\t$full\t", int($full/$sum*10000)/100, "\t" ;
    my $uniq = scalar(keys %hstat) ;
    print ST "$uniq\n" ;
    print ST "PART\t$part\t", int($part/$sum*10000)/100, "\n" ;
    print ST "NULL\t$null\t", int($null/$sum*10000)/100, "\n" ;
    print ST "MULT\t$mult\t", int($mult/$sum*10000)/100, "\n" ;
    close(ST) ;

    return ;
}

#my $mult_flag = &judge_mult_bc(\@ref_poses, \@map_poses, $minkmer);
sub judge_mult_bc()
{
    my ($aref_poses, $amap_poses, $minkmer) = @_ ;

    my $mult_flag = 0 ;
    my @ref_regions = ();
    push @ref_regions, [$aref_poses->[0], $aref_poses->[0]] ;
    for (my $i=1; $i<@{$aref_poses}; $i++){
        if ($aref_poses->[$i] > $aref_poses->[$i-1]){
            if (abs(($aref_poses->[$i] - $aref_poses->[$i-1]) - ($amap_poses->[$i]- $amap_poses->[$i-1])) < 3){
                $ref_regions[-1][1] = $aref_poses->[$i] ;
            }
            else{
                push @ref_regions, [$aref_poses->[$i], $aref_poses->[$i]] ;
            }
        }
        else{
            push @ref_regions, [$aref_poses->[$i], $aref_poses->[$i]] ;
        }
    }
    my @filter_region = ();
    for (my $i=0; $i<@ref_regions; $i++){
        next if ($ref_regions[$i][1] - $ref_regions[$i][0] < $minkmer);
        push @filter_region, $ref_regions[$i] ;
    }
    return(0) if (scalar @filter_region < 2);
    @filter_region = sort {$a->[0]<=>$b->[0]||$a->[1]<=>$b->[1]} @filter_region ;
    for (my $i=1; $i<@filter_region; $i++){
        if ($filter_region[$i][0] < $filter_region[$i-1][1]){
            $mult_flag = 1 ;
            last ;
        }
    }

    return($mult_flag);
}

