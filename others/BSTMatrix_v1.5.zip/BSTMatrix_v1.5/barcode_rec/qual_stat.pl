#!/usr/bin/perl -w
my $ver="1.0";

use strict ;
use Getopt::Long;
use Data::Dumper;
use FindBin qw($Bin $Script);
use File::Basename qw(basename dirname);

#####################

my %opts;
GetOptions(\%opts,"f1=s","f2=s","p=s","o=s","t=s","h" );

#&help()if(defined $opts{h});
if(!defined($opts{f1}) || !defined($opts{f2}) || !defined($opts{p}) || !defined($opts{o}) || defined($opts{h}))
{
	print <<"	Usage End.";
	Description:
		
		Version: $ver
		   v1.0: stat quality.

	Usage:

		-f1          read1 fastq file             <infile>     must be given
		-f2          read2 fastq file             <infile>     must be given
		-p           pos file                     <infile>     must be given
		-o           result file                  <outfile>    must be given
		-t           quality type                 [int]        optional [33]
		-h           Help document

	Usage End.

	exit;
}

###############Time
my $Time_Start;
$Time_Start = sub_format_datetime(localtime(time()));
&show_log("Start Time :[$Time_Start]");
################
$| = 1 ;

## get parameters
my $fq1file = $opts{f1} ;
my $fq2file = $opts{f2} ;
my $posfile = $opts{p} ;
my $outfile = $opts{o} ;
my $qual_type = defined $opts{t} ? $opts{t} : 33 ;

my %href_len = (
	'bc1'   => 17 ,
	'bc2'   => 19 ,
	'bc3'   => 19 ,
    'umi'   => 12 ,
);

# get pos info
my %hpos = ();
my ($bc_reads_num, $bc_full_num) = &get_pos_info($posfile, \%hpos);

## stat quality
my %hstat = ();
my $reads_num = &quality_stat($fq1file, $fq2file, \%hpos, \%href_len, $qual_type, \%hstat);

## out put
&output($outfile, \%hstat, $reads_num, $bc_reads_num, $bc_full_num);

###############Time
my $Time_End;
$Time_End = sub_format_datetime(localtime(time()));
&show_log("End Time :[$Time_End]");

###############Subs
sub sub_format_datetime {#Time calculation subroutine
    my($sec, $min, $hour, $day, $mon, $year, $wday, $yday, $isdst) = @_;
	$wday = $yday = $isdst = 0;
    sprintf("%4d-%02d-%02d %02d:%02d:%02d", $year+1900, $mon+1, $day, $hour, $min, $sec);
}

sub ABSOLUTE_DIR
{ #$pavfile=&ABSOLUTE_DIR($pavfile);
	my $cur_dir=`pwd`;
	$cur_dir =~ s/\n$//;
	my ($in)=@_;
	my $return="";
	
	if(-f $in)
	{
		my $dir=dirname($in);
		my $file=basename($in);
		chdir $dir;$dir=`pwd`;
		$dir =~ s/\n$// ;
		$return="$dir/$file";
	}
	elsif(-d $in)
	{
		chdir $in;$return=`pwd`;
		$return =~ s/\n$// ;
	}
	else
	{
		warn "Warning just for file and dir [$in]\n";
		exit;
	}
	
	chdir $cur_dir;
	return $return;
}

# &show_log("txt")
sub show_log()
{
	my ($txt) = @_ ;
	my $time = time();
	my $Time = &sub_format_datetime(localtime($time));
	print "$Time:\t$txt\n" ;
	return ($time) ;
}

#&run_or_die($cmd);
sub run_or_die()
{
	my ($cmd) = @_ ;
	my $start_time = &show_log($cmd);
	my $flag = system($cmd) ;
	if ($flag != 0){
		my $end_time = &show_log("Error: command fail: $cmd");
		&show_log("Elaseped time: ".($end_time - $start_time)."s\n");
		exit(1);
	}
	my $end_time = &show_log("done.");
	&show_log("Elaseped time: ".($end_time - $start_time)."s\n");
	return ;
}

#my ($bc_reads_num, $bc_full_num) = &get_pos_info($posfile, \%hpos);
sub get_pos_info()
{
    my ($posfile, $ahpos) = @_ ;

    open (IN, $posfile) || die "$posfile, $!\n" ;
    my $bc_reads_num = 0 ;
    my $bc_full_num = 0 ;
    while(<IN>){
        chomp ;
        next if (m/^\#|^\s*$/);
        my ($id, $bcs, $poses, $umi_pos) = split ;
        my @bc_types = split /\-/, $bcs ;
        my @bc_poses = split /\-/, $poses ;
        $bc_reads_num ++ ;
        my $bc_num = 0 ;
        for (my $i=0; $i<@bc_types; $i++){
            my $bc = $bc_types[$i] ;
            my $pos = $bc_poses[$i] ;
            $ahpos->{$id}{$bc} = $pos ;
            $bc_num++ ;
        }
        if ($bc_num == 3){
            $bc_full_num++ ;
        }
        $ahpos->{$id}{umi} = $umi_pos ;
    }
    close(IN);

    return($bc_reads_num, $bc_full_num);
}

#&quality_stat($fq1file, $fq2file, \%hpos, \%href_len, $qual_type, \%hstat);
sub quality_stat()
{
    my ($fq1file, $fq2file, $ahpos, $ahref_len, $qual_type, $ahstat) = @_ ;

    open (FQ1, $fq1file) || die "$fq1file, $!\n" ;
    open (FQ2, $fq2file) || die "$fq2file, $!\n" ;
    my $reads_num = 0 ;
    while(<FQ1>){
        my $id1 = $_ ;
        my $seq1 = <FQ1> ;
        my $u1 = <FQ1> ;
        my $qual1 = <FQ1> ;
        my $id2 = <FQ2> ;
        my $seq2 = <FQ2> ;
        my $u2 = <FQ2> ;
        my $qual2 = <FQ2> ;
        chomp($id1, $id2, $seq1, $seq2, $u1, $u2, $qual1, $qual2) ;
        $id1 = (split /\s+/, $id1)[0] ;
        $id1 =~ s/^\@// ;
        if (defined $ahpos->{$id1}){
            for my $type (keys %{$ahpos->{$id1}}){
                my $pos = $ahpos->{$id1}{$type} ;
                my $len = $ahref_len->{$type} ;
                my $qual_seq = substr($qual1, $pos, $len) ;
                my ($pass_qual, $fail_qual) = &quality_check($qual_seq, $qual_type);
                $ahstat->{$type}{'pass_qual'} += $pass_qual ;
                $ahstat->{$type}{'fail_qual'} += $fail_qual ;
            }
            my ($pass_qual, $fail_qual) = &quality_check($qual2, $qual_type);
            $ahstat->{'RNA'}{'pass_qual'} += $pass_qual ;
            $ahstat->{'RNA'}{'fail_qual'} += $fail_qual ;
        }
        $reads_num++ ;
    }
    close(FQ1) ;
    close(FQ2) ;

    return($reads_num);
}

#my ($pass_qual, $fail_qual) = &quality_check($qual_seq, $qual_type);
sub quality_check()
{
    my ($qual_seq, $qual_type) = @_ ;

    my $pass_num = 0 ;
    my $fail_num = 0 ;
    for (my $i=0; $i<length($qual_seq); $i++){
        my $char = substr($qual_seq, $i, 1) ;
        my $qual = ord($char) - $qual_type ;
        next if ($qual <= 2) ;
        if ($qual >= 30){
            $pass_num ++ ;
        }
        else{
            $fail_num ++ ;
        }
    }

    return($pass_num, $fail_num);
}

#&output($outfile, \%hstat, $reads_num, $bc_reads_num, $bc_full_num);
sub output()
{
    my ($outfile, $ahstat, $reads_num, $bc_reads_num, $bc_full_num) = @_ ;

    open (OUT, ">$outfile") || die "$outfile, $!\n" ;
    print OUT "Number of Reads\t$reads_num\n" ;
    print OUT "Valid Barcodes\t$bc_full_num\n" ;
    print OUT "Valid UMIs\t$bc_reads_num\n" ;
    my $bc_pass_num = 0 ;
    my $bc_fail_num = 0 ;
    for my $type (qw/bc1 bc2 bc3/){
        $bc_pass_num += $ahstat->{$type}{'pass_qual'} ;
        $bc_fail_num += $ahstat->{$type}{'fail_qual'} ;
    }
    my $bc_total_num = $bc_pass_num + $bc_fail_num ;
    print OUT "Q30 Bases in Barcode\t", int($bc_pass_num/$bc_total_num*10000+0.5)/100, "%\n" ;
    my $rna_pass_num = $ahstat->{RNA}{'pass_qual'} ;
    my $rna_fail_num = $ahstat->{RNA}{'fail_qual'} ;
    my $rna_total_num = $rna_pass_num + $rna_fail_num ;
    print OUT "Q30 Bases in RNA Read\t", int($rna_pass_num/$rna_total_num*10000+0.5)/100, "%\n" ;
    my $umi_pass_num = $ahstat->{umi}{'pass_qual'} ;
    my $umi_fail_num = $ahstat->{umi}{'fail_qual'} ;
    my $umi_total_num = $umi_pass_num + $umi_fail_num ;
    print OUT "Q30 Bases in UMI\t", int($umi_pass_num/$umi_total_num*10000+0.5)/100, "%\n" ;
    close(OUT);

    return ;
}

