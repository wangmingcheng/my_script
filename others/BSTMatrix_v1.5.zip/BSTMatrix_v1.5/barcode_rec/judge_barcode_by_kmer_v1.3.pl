#!/usr/bin/perl -w
use strict ;

if (@ARGV < 3){
    print "v1.2: change position info\n" ;
    print "v1.3: change sort position\n" ;
	print "Usage: perl $0 infqfile kmerfile outfile [kmer:9]\n" ;
	exit(1);
}

my ($fqfile, $kmerfile, $outfile, $kmerlen) = @ARGV ;
$kmerlen ||= 9 ;

my %hkmer = ();
my %hpos = ();
&get_kmer($kmerfile, \%hkmer, \%hpos);

&read_fq_and_check_barcode($fqfile, $outfile, \%hkmer, \%hpos, $kmerlen);



#&get_kmer($kmerfile, \%hkmer, \%hpos);
sub get_kmer()
{
	my ($kmerfile, $ahkmer, $ahpos) = @_ ;

	open (IN, $kmerfile) || die "$kmerfile, $!\n" ;
	while(<IN>){
		chomp ;
		next if (m/^\s*$|^\#/);
		my ($kmer, $num, @ids) = split ;
		if ($num == 1){
			$ahkmer->{$kmer} = $ids[0] ;
			$ahpos->{$kmer} = $ids[1] ;
		}
	}
	close(IN);

	return ;
}

#&read_fq_and_check_barcode($fqfile, $outfile, \%hkmer, \%hpos, $kmerlen);
sub read_fq_and_check_barcode()
{
	my ($fqfile, $outfile, $ahkmer, $ahpos, $kmerlen) = @_ ;

	open (IN, $fqfile) || die "$fqfile, $!\n" ;
	open (OUT, ">$outfile") || die "$outfile, $!\n" ;
	while(<IN>){
		my $id = $_ ;
		my $seq = <IN> ;
		my $id2 = <IN> ;
		my $qual = <IN> ;
		chomp($id, $seq, $id2, $qual);
		$id = (split /\s+/, $id)[0] ;
		$id =~ s/^\@// ;
		my $len = length($seq) ;
		my %htypes = ();
        #my %hkmer_pos = ();
        my %hkmer_ref = ();
		for (my $i=0; $i<$len-$kmerlen+1; $i++){
			my $kmer = substr($seq, $i, $kmerlen);
			if (defined $ahkmer->{$kmer}){
				$htypes{$ahkmer->{$kmer}}++ ;
                push @{$hkmer_ref{$ahkmer->{$kmer}}}, [$ahpos->{$kmer}, $i] ;
                #push @{$hkmer_ref{$ahkmer->{$kmer}}}, $ahpos->{$kmer} ;
                #push @{$hkmer_pos{$ahkmer->{$kmer}}}, $i;
			}
		}
		print OUT "$id" ;
		for my $key (sort {$htypes{$b}<=>$htypes{$a}} keys %htypes){
            #my @kmer_pos = sort {$a<=>$b} @{$hkmer_pos{$key}} ;
            #my @ref_pos = sort {$a<=>$b} @{$hkmer_ref{$key}} ;
            my @poses = sort {$a->[1]<=>$b->[1]} @{$hkmer_ref{$key}} ;
            my @ref_pos = ();
            my @kmer_pos = ();
            for (my $i=0; $i<@poses; $i++){
                push @ref_pos, $poses[$i][0] ;
                push @kmer_pos, $poses[$i][1] ;
            }
			print OUT " $key:", $htypes{$key}, ":", join(',', @ref_pos) ,":", join(',', @kmer_pos) ;
		}
		print OUT "\n" ;
	}
	close(IN);
	close(OUT);

	return ;
}

