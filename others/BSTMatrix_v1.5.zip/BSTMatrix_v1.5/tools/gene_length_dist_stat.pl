#!/usr/bin/perl -w
# 
# Copyright (c) BIO_MARK 2021
# Writer:         Dengdj <dengdj@biomarker.com.cn>
# Program Date:   2021
# Modifier:       Dengdj <dengdj@biomarker.com.cn>
# Last Modified:  2021
my $ver="1.0";

use strict;
use Getopt::Long;
use Data::Dumper;
use FindBin qw($Bin $Script);
use File::Basename qw(basename dirname);

#####################

my %opts;
GetOptions(\%opts,"i=s","g=s","o=s","h" );

#&help()if(defined $opts{h});
if(!defined($opts{i}) || !defined($opts{g}) || !defined($opts{o}) || defined($opts{h}))
{
	print <<"	Usage End.";
	Description:
		
		Version: $ver

	Usage:

		-i           umi gene file                     <infile>     must be given
		-g           gff3 file                         <infile>     must be given
		-o           result file                       <outfile>    must be given
		-h           Help document

	Usage End.

	exit;
}

###############Time
my $Time_Start;
$Time_Start = sub_format_datetime(localtime(time()));
&show_log("Start Time :[$Time_Start]");
################
$| = 1 ;
## get parameters
my $umifile = $opts{i} ;
my $gfffile = $opts{g} ;
my $outfile = $opts{o} ;

## reading umi file
my %humi_gene = ();
&get_umi_gene($umifile, \%humi_gene);

## reading gff3 file
my %hgene = ();
&get_gene_length($gfffile, \%hgene);

## stat and output
&stat_and_output(\%humi_gene, \%hgene, $outfile) ;

###############Time
my $Time_End;
$Time_End = sub_format_datetime(localtime(time()));
&show_log("End Time :[$Time_End]");

###############Subs
sub sub_format_datetime {#Time calculation subroutine
    my($sec, $min, $hour, $day, $mon, $year, $wday, $yday, $isdst) = @_;
	$wday = $yday = $isdst = 0;
    sprintf("%4d-%02d-%02d %02d:%02d:%02d", $year+1900, $mon+1, $day, $hour, $min, $sec);
}

sub ABSOLUTE_DIR
{ #$pavfile=&ABSOLUTE_DIR($pavfile);
	my $cur_dir=`pwd`;
	$cur_dir =~ s/\n$//;
	my ($in)=@_;
	my $return="";
	
	if(-f $in)
	{
		my $dir=dirname($in);
		my $file=basename($in);
		chdir $dir;$dir=`pwd`;
		$dir =~ s/\n$// ;
		$return="$dir/$file";
	}
	elsif(-d $in)
	{
		chdir $in;$return=`pwd`;
		$return =~ s/\n$// ;
	}
	else
	{
		warn "Warning just for file and dir [$in]\n";
		exit;
	}
	
	chdir $cur_dir;
	return $return;
}

# &show_log("txt")
sub show_log()
{
	my ($txt) = @_ ;
	my $time = time();
	my $Time = &sub_format_datetime(localtime($time));
	print "$Time:\t$txt\n" ;
	return ($time) ;
}

#&run_or_die($cmd);
sub run_or_die()
{
	my ($cmd) = @_ ;
	my $start_time = &show_log($cmd);
	my $flag = system($cmd) ;
	if ($flag != 0){
		my $end_time = &show_log("Error: command fail: $cmd");
		&show_log("Elaseped time: ".($end_time - $start_time)."s\n");
		exit(1);
	}
	my $end_time = &show_log("done.");
	&show_log("Elaseped time: ".($end_time - $start_time)."s\n");
	return ;
}

## qsub
sub qsub()
{
	my ($shfile, $maxproc) = @_ ;
	my $dir = dirname($shfile) ;
	my $cmd = "cd $dir && sh /share/nas2/genome/bmksoft/tool/qsub_sge_plus/v1.0/qsub_sge.plus.sh --maxproc $maxproc --reqsub --independent $shfile" ;
	&run_or_die($cmd);

	return ;
}

## qsub_mult($shfile, $max_proc, $job_num)
sub qsub_mult()
{
	my ($shfile, $max_proc, $job_num) = @_ ;
	if ($job_num > 500){
		my @shfiles = &cut_shfile($shfile);
		for my $file (@shfiles){
			&qsub($file, $max_proc);
		}
	}
	else{
		&qsub($shfile, $max_proc) ;
	}
}

#my @shfiles = &cut_shfile($shfile);
sub cut_shfile()
{
	my ($file) = @_ ;
	my @files = ();
	my $num = 0 ;
	open (IN, $file) || die "Can't open $file, $!\n" ;
	(my $outprefix = $file) =~ s/.sh$// ;
	while (<IN>){
		chomp ;
		if ($num % 500 == 0){
			close(OUT);
			my $outfile = "$outprefix.sub_".(int($num/500)+1).".sh" ;
			push @files, $outfile ;
			open (OUT, ">$outfile") || die "Can't creat $outfile, $!\n" ;
		}
		print OUT $_, "\n" ;
		$num ++ ;
	}
	close(IN);
	close(OUT);

	return @files ;
}

sub sub_normal_dis_ran(){#$average,$standard_deviation
        my ($aver,$stand_dev) = @_ ;
        my $ran1 = rand() ;
        my $ran2 = rand() ;
        my $y = ((-2*log($ran1))**(0.5))*sin(2*3.1415926535*$ran2) ;
        return ($aver + $stand_dev*$y) ;
}

#&get_umi_gene($umifile, \%humi_gene);
sub get_umi_gene()
{
    my ($umifile, $ahumi_gene) = @_ ;

    open (IN, $umifile) || die "$umifile, $!\n" ;
    while(<IN>){
        chomp ;
        next if (m/^\#|^\s*$/);
        my ($bc_type, $umi, $gene) = split ;
        $ahumi_gene->{$gene}++ ;
    }
    close(IN);

    return ;
}

#&get_gene_length($gfffile, \%hgene);
sub get_gene_length()
{
    my ($gfffile, $ahgene) = @_ ;

    open (IN, $gfffile) || die "$gfffile, $!\n" ;
    while(<IN>){
        chomp ;
        next if (m/^\#/);
        my ($chr, undef, $type, $start, $end, undef, $ori, undef, $infos) = split ;
        if ($type =~ m/gene/i){
            next if ($type =~ m/segment/);
            my $len = $end - $start + 1 ;
            if ($infos =~ m/ID=(.*?)\;/){
                my $gene_id = $1 ;
                $ahgene->{$gene_id} = $len ;
            }
            elsif ($infos =~ m/ID=([^;]*?)\s*$/){
                my $gene_id = $1 ;
                $ahgene->{$gene_id} = $len ;
            }
        }
    }
    close(IN);

    return ;
}

#&stat_and_output(\%humi_gene, \%hgene, $outfile) ;
sub stat_and_output()
{
    my ($ahumi_gene, $ahgene, $outfile) = @_ ;

    my $max_index = 0 ;
    my %hlen = ();
    for my $gene (keys %{$ahumi_gene}){
        my $len = $ahgene->{$gene} ;
        my $num = $ahumi_gene->{$gene} ;
        my $index = int($len/100) ;
        $hlen{$index}{$gene} = $num ;
        $max_index = $index if ($index > $max_index);
    }

    my %hall_len = ();
    for my $gene (keys %{$ahgene}){
        my $len = $ahgene->{$gene} ;
        my $index = int($len/100) ;
        $hall_len{$index}{$gene}++ ;
        $max_index = $index if ($index > $max_index);
    }

    open (OUT, ">$outfile") || die "$outfile, $!\n" ;
    for (my $i=0; $i<=$max_index; $i++){
        my $min = $i*100 ;
        my $max = ($i+1)*100 ;
        my $gene_num = 0 ;
        my $umi_num = 0 ;
        my $all_num = 0 ;
        if (defined $hlen{$i}){
            $gene_num = scalar(keys %{$hlen{$i}});
            for my $gene (keys %{$hlen{$i}}){
                $umi_num += $hlen{$i}{$gene} ;
            }
        }
        if (defined $hall_len{$i}){
            $all_num = scalar(keys %{$hall_len{$i}}) ;
        }
        print OUT "$min-$max\t$all_num\t$gene_num\t$umi_num\n" ;
    }
    close(OUT) ;

    return ;
}

