#!/usr/bin/perl -w
use strict ;

if (@ARGV < 3){
    print "Usage: perl $0 infile outfile cutlen [type:B/E]\n" ;
    exit(1);
}

my ($infile, $outfile, $cutlen, $type) = @ARGV ;
$type ||= "B" ;

if ($infile =~ /\.fa$|\.fasta$/i){
    open (IN, $infile) || die "$infile, $!\n" ;
    open (OUT, ">$outfile") || die "$outfile, $!\n" ;
    $/ = ">" ;
    while(<IN>){
        chomp ;
        next if (m/^\s*$/);
        my ($id, $seq) = split /\n/, $_, 2 ;
        $seq =~ s/\n//g ;
        my $len = length($seq) ;
        if ($type eq 'E'){
            my $new_seq = substr($seq, $len-$cutlen, $cutlen);
            print OUT ">$id\n$new_seq\n" ;
        }
        else{
            my $new_seq = substr($seq, 0, $cutlen);
            print OUT ">$id\n$new_seq\n" ;
        }
    }
    $/ = "\n" ;
    close(IN);
    close(OUT);
}
elsif($infile =~ /\.fq$|\.fastq$/i){
    open (IN, $infile) || die "$infile, $!\n" ;
    open (OUT, ">$outfile") || die "$outfile, $!\n" ;
    while(<IN>){
        my $id = $_ ;
        my $seq = <IN> ;
        my $id2 = <IN> ;
        my $qual = <IN> ;
        chomp($id, $seq, $id2, $qual);
        my $len = length($seq) ;
        if ($type eq 'E'){
            my $new_seq = substr($seq, $len-$cutlen, $cutlen);
            my $new_qual = substr($qual, $len-$cutlen, $cutlen);
            print OUT "$id\n$new_seq\n\+\n$new_qual\n" ;
        }
        else{
            my $new_seq = substr($seq, 0, $cutlen);
            my $new_qual = substr($qual, 0, $cutlen) ;
            print OUT "$id\n$new_seq\n\+\n$new_qual\n" ;
        }
    }
    close(IN);
    close(OUT);
}

