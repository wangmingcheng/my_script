#!/usr/bin/perl -w
use strict ;

if (@ARGV < 5){
    print "v1.2: modify for READ1+BC1+LINK1+BC2+小段+BC3+UMI+ployT+cdna+SSP\n" ;
    print "v1.3: modify for READ1+BC1+小段+BC2+小段+BC3+UMI+ployT+cdna+SSP\n" ;
	print "Usage:\n\tperl $0 bc1 bc2 bc3 refseq outfile [kmer:9]\n" ;
	exit(1) ;
}

my ($bc1file, $bc2file, $bc3file, $reffile, $outfile, $kmerlen) = @ARGV ;
$kmerlen ||= 9 ;

my %hlen = (
	'bc1'   => 1 ,
	'bc2'   => 23 ,
	'bc3'   => 48 ,
);

my %hkmer = ();

&get_kmer($bc1file, $kmerlen, \%hkmer, \%hlen);
&get_kmer($bc2file, $kmerlen, \%hkmer, \%hlen);
&get_kmer($bc3file, $kmerlen, \%hkmer, \%hlen);
&get_kmer($reffile, $kmerlen, \%hkmer, \%hlen);

&output(\%hkmer, $outfile);



#&get_kmer($bc1file, $kmerlen, \%hkmer, \%hlen);
sub get_kmer()
{
	my ($file, $kmerlen, $ahkmer, $ahlen) = @_ ;

	open (IN, $file) || die "$file, $!\n" ;
	$/ = ">" ;
	while(<IN>){
		chomp ;
		next if (m/^\s*$/);
		my ($id, $seq) = split /\n/, $_, 2 ;
		$id = (split /\s+/, $id)[0] ;
		$seq =~ s/\n//g ;
		my $revseq = &revcom($seq);
		my $len = length($seq) ;
		(my $type = $id) =~ s/(bc\d)\_\d+/$1/ ;
		$ahlen->{$type} ||= 0 ;
		for (my $i=0; $i<$len-$kmerlen+1; $i++){
			my $kmer = substr($seq, $i, $kmerlen);
			my $revkmer = substr($revseq, $i, $kmerlen);
			push @{$ahkmer->{$kmer}}, [$id, $i+$ahlen->{$type}] ;
			push @{$ahkmer->{$revkmer}}, [$id, $len-$kmerlen-$i+$ahlen->{$type}] ;
		}
	}
	$/ = "\n" ;
	close(IN);

	return ;
}

#my $revseq = &revcom($seq);
sub revcom()
{
	my ($seq) = @_ ;

	$seq =~ tr/ACGTacgt/TGCAtgca/ ;
	$seq = reverse($seq) ;

	return($seq) ;
}

#&output(\%hkmer, $outfile);
sub output()
{
	my ($ahkmer, $outfile) = @_ ;

	open (OUT, ">$outfile") || die "$outfile, $!\n" ;
	for my $kmer (keys %{$ahkmer}){
		my $num = scalar(@{$ahkmer->{$kmer}}) ;
		print OUT "$kmer\t$num" ;
		for (my $i=0; $i<@{$ahkmer->{$kmer}}; $i++){
			print OUT "\t", $ahkmer->{$kmer}[$i][0], "\t", $ahkmer->{$kmer}[$i][1] ;
		}
		print OUT "\n" ;
	}
	close(OUT);

	return ;
}

