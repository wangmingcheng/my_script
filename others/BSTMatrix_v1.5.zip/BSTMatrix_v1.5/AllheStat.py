# -*- coding: UTF-8 -*-
from BSTools.SupspotROI import SupspotROI
import cv2
import os
import getopt
import sys
import pandas as pd
import json
import shutil

# os.makedirs('D:/outdir/hello/world/')
# exit()




def open_level_gene_matrix(level_dir):
    # init
    levels = []
    # 提取目录下的levels
    os_walk = os.walk(level_dir)
    _, dirs, _ = os_walk.__next__()
    for curr_dir in dirs:
        if len(curr_dir) < 7:
            continue
        if curr_dir[0:6] == 'level_':
            print(f"{curr_dir}")
            levels.append(int(curr_dir[6:]))
    if len(levels) == 0:
        return 0
    levels.sort(reverse=True)
    return levels
    pass





def gen_one_roi_level_matrix(img_ori, curr_level, outdir, level_dir, roi_json_file, roi_key='heAuto'):
    # 构建SupspotROI
    sroi = SupspotROI(img_ori, curr_level)

    # 创建输出目录
    subdata_key = f"L{curr_level}_{roi_key}"
    subdata_dir = f"{outdir}/subdata/{subdata_key}/"
    if not os.path.exists(subdata_dir):
        os.makedirs(subdata_dir)
    # 生成subdata
    level_dir = f"{level_dir}/level_{curr_level}/"
    json_file = roi_json_file
    roi_group = sroi.read_roi_group_f_file(json_file)
    roi_mask = sroi.cal_roi_group_mask(roi_group)
    sroi.link_level_roi(level_dir=level_dir, roi_mask=roi_mask, outdir=subdata_dir)
    pass

# 统计测序饱和度
def sequencing_saturation(infile, iszip=True):
    if iszip:
        df = pd.read_csv(infile, compression='gzip', sep='\t', names=['bc_name', 'umi_seq', 'read_count'], header=None)
    else:
        df = pd.read_csv(infile, sep='\t', names=['bc_name', 'umi_seq', 'read_count'], header=None)

    one_count = df['read_count'] == 1
    rate = 1.0 - sum(one_count) / df.shape[0]
    return rate

# 统计supspot数量，中位基因数，中位UMI数
def median_num_stat(matrix_file, skiprows=3):
    df = pd.read_csv(matrix_file, compression='gzip', sep='\t', names=['gene', 'supspot', 'umi'], skiprows=skiprows,
                     header=None)

    supspot_num = df['supspot'].value_counts().shape[0]
    median_gene_num = df['supspot'].value_counts().median()
    median_umi_num = df['umi'].astype(float).groupby(df['supspot']).sum().median()
    total_gene_num = df['gene'].value_counts().shape[0]
    return([supspot_num, median_gene_num, median_umi_num, total_gene_num])
    pass

# supspot的中位read数与平均read数
def mean_read_num_stat(bc_read_file, bc_list_file):
    infos = {}
    read_count = pd.read_csv(bc_read_file, compression='gzip', sep='\t', names=['bc_name', 'read_num'], header=None)
    infos['total_supspot_num'] = read_count.shape[0]
    infos['total_chip_read_num'] = read_count['read_num'].sum()
    infos['total_supspot_mean_num'] = read_count['read_num'].mean()
    bc_list = pd.read_csv(bc_list_file, compression='gzip', sep='\t', names=['bc_name'], header=None)
    tissue_read_count = pd.merge(bc_list,read_count,how='left')
    print(tissue_read_count.head())
    infos['tissue_supspot_num'] = tissue_read_count.shape[0]
    infos['tissue_read_num'] = tissue_read_count['read_num'].sum()
    infos['tissue_supspot_read_mean_num'] = tissue_read_count['read_num'].mean()
    infos['tissue_supspot_read_median_num'] = tissue_read_count['read_num'].median()
    return infos
    pass

def stat_info(used_args):
    print(f"args:{used_args}")
    # 统计测序饱和度
    seq_sat = sequencing_saturation(infile=f"{used_args['matrix_dir']}/bc_umi_read.tsv.gz")

    # 统计组织覆盖的supspot数
    matrix_file = f"{used_args['outdir']}/heAuto_level_matrix/subdata/L7_heAuto/matrix.mtx.gz"
    supspot_num, median_gene_num, median_umi_num, total_gene_num = median_num_stat(matrix_file=matrix_file)

    # 统计read相关的信息
    bc_read_file = f"{used_args['outdir']}/level_matrix/level_7/barcodes_read.tsv.gz"
    bc_list_file = f"{used_args['outdir']}/heAuto_level_matrix/subdata/L7_heAuto/barcodes.tsv.gz"
    infos = mean_read_num_stat(bc_read_file, bc_list_file)

    # output
    outfile = f"{used_args['outdir']}/stat.txt"
    # info_names = ['total_supspot_num', 'total_chip_read_num', 'total_supspot_mean_num', 'tissue_supspot_num', 'tissue_read_num', 'tissue_supspot_read_mean_num', 'tissue_supspot_read_median_num']
    info_names = ['total_supspot_num', 'total_chip_read_num', 'total_supspot_mean_num', 'tissue_read_num', 'tissue_supspot_read_mean_num', 'tissue_supspot_read_median_num']
    with open(outfile,'w') as fp:
        fp.write(f"sequencing_saturation\t{seq_sat*100:.2f}%\n")
        for i in range(len(info_names)):
            fp.write(f"{info_names[i]}\t{infos[info_names[i]]}\n")
        fp.write(f"supspot_num\t{supspot_num}\ntissue_percent\t{supspot_num/infos['total_supspot_num']*100:.2f}%\n")
        fp.write(f"median_gene_num\t{median_gene_num}\nmedian_umi_num\t{median_umi_num}\ntotal_gene_num\t{total_gene_num}\n")

    pass


def stat_all_level_info(used_args):
    # init
    outdir = used_args['outdir']
    levels = used_args['levels'].split(',')
    df = pd.DataFrame()
    name = ['level', 'supspot_num', 'median_gene_num', 'median_umi_num', 'total_gene_num']
    df['name'] = name
    # all level stat
    for level in levels:
        matrix_file = f"{outdir}/heAuto_level_matrix/subdata/L{level}_heAuto/matrix.mtx.gz"
        supspot_num, median_gene_num, median_umi_num, total_gene_num = median_num_stat(matrix_file=matrix_file)
        curr_level = f"level{level}"
        df[curr_level] = [int(level), supspot_num, median_gene_num, median_umi_num, total_gene_num]
    # output
    content = df.to_csv(sep='\t', header=False, index=False, line_terminator='\n', float_format='%.0f')
    content = content.encode(encoding='utf-8')
    outfile = f"{outdir}/all_level_stat.txt"
    with open(outfile, "wb") as fp:
        fp.write(content)
    pass


def pack_bstviewer_project(used_args):
    project_dir = f"{used_args['outdir']}/BSTViewer_project"
    if not os.path.exists(project_dir):
        os.makedirs(project_dir)
    # 创建JSON，并进行初始化
    json_dict = {}
    json_dict['project_json_filename'] = './project_setting.json'
    json_dict['he_filepath'] = './he.tif'
    json_dict['level_gene_matrix_dirpath'] = './level_matrix'
    json_dict['levels'] = list(map(lambda x: int(x), used_args['levels'].split(',')))
    json_dict['curr_level_index'] = 0
    json_dict['cluster_keys'] = []
    json_dict['curr_cluster_index'] = 0
    json_dict['roi_keys'] = ["Lall","heAuto"]
    json_dict['curr_roi_index'] = 0
    json_dict['subdata_keys'] = list(map(lambda x:f"L{x}_heAuto", json_dict['levels']))
    # 生成配置文件
    with open(f'{project_dir}/project_setting.json', "w") as fp:
        json.dump(json_dict, fp, indent=4)

    # 生成各级子目录
    roi_group_dir = f"{project_dir}/roi_groups/"
    if not os.path.exists(roi_group_dir):
        os.mkdir(roi_group_dir)
    cluster_dir = f"{project_dir}/cluster/"
    if not os.path.exists(cluster_dir):
        os.mkdir(cluster_dir)
    subdata_dir = f"{project_dir}/subdata/"
    if os.path.exists(subdata_dir):
        shutil.rmtree(subdata_dir)
    img_dir = f"{project_dir}/imgs/"
    if not os.path.exists(img_dir):
        os.mkdir(img_dir)

    # 拷贝HE图片
    shutil.copy(used_args['he_file'], f"{project_dir}/he.tif")
    # 拷贝level matrix
    if os.path.exists(f"{project_dir}/level_matrix"):
        shutil.rmtree(f"{project_dir}/level_matrix")
    shutil.copytree(f"{used_args['outdir']}/level_matrix", f"{project_dir}/level_matrix")
    # 拷贝roi
    # roi_heAuto
    shutil.copy(f"{used_args['outdir']}/allhe/roi_heAuto.json", f"{project_dir}/roi_groups/roi_heAuto.json")
    # roi_Lall
    img_ori = cv2.imread(f"{project_dir}/he.tif")
    width, height = img_ori.shape[0:2]
    swap_roi = [[]]
    # 保存坐标点
    swap_roi[-1].append([0, 0])
    swap_roi[-1].append([width, 0])
    swap_roi[-1].append([width, height])
    swap_roi[-1].append([0, height])
    json_dict = {}
    json_dict['ori_group'] = swap_roi
    with open(f"{project_dir}/roi_groups/roi_Lall.json", "w") as fp:
        json.dump(json_dict, fp, indent=4)
    # 拷贝subdata
    shutil.copytree(f"{used_args['outdir']}/heAuto_level_matrix/subdata", f"{project_dir}/subdata")
    pass

def do_something(used_args):
    # 创建输出目录
    outdir = os.path.abspath(used_args['outdir'])
    outdir = '/'.join(outdir.split('\\'))
    used_args['outdir'] = outdir
    if not os.path.exists(outdir):
        os.makedirs(outdir)

    # calling level matrix
    matrix_dir = os.path.abspath(used_args['matrix_dir'])
    matrix_dir = '/'.join(matrix_dir.split('\\'))
    used_args['matrix_dir'] = matrix_dir
    pydir = os.path.dirname(os.path.abspath(sys.argv[0]))
    pydir = '/'.join(pydir.split('\\')) + '/BSTools/'
    # os.system(f"python {pydir}/levelMatrix.py -i {matrix_dir} -o {outdir}/level_matrix/ -L 13,7,5,4,3,2,1")
    # cmd_str = f"python {pydir}/levelMatrix.py -i {matrix_dir} -o {outdir}/level_matrix/ -L 13,7,5"
    levels = "13,7,6,5,4,3,2,1"
    cmd_str = f"{sys.executable} {pydir}/levelMatrix.py -i {matrix_dir} -o {outdir}/level_matrix/ -L {levels}"
    print(f"cmd:{cmd_str}")
    os.system(cmd_str)

    # 自动识别HE区域
    he_file = os.path.abspath(used_args['he_file'])
    he_file = '/'.join(he_file.split('\\'))
    used_args['he_file'] = he_file
    cmd_str = f"{sys.executable} {pydir}/HERegionSearch.py -i {he_file} -o {outdir}/allhe/"
    print(f"cmd:{cmd_str}")
    os.system(cmd_str)

    # 生成HE区域的level matrix
    cmd_str = f"{sys.executable} {pydir}/RoiLevelMatrix.py -e {he_file} -o {outdir}/heAuto_level_matrix -m {outdir}/level_matrix/ -r {outdir}/allhe/roi_heAuto.json"
    print(f"cmd:{cmd_str}")
    os.system(cmd_str)

    # 绘制umi count分布图
    if not os.path.exists(f"{outdir}/umi_plot/"):
        os.makedirs(f"{outdir}/umi_plot/")
    cmd_str = f"{sys.executable} {pydir}/UMICountDistPlot.py -e {he_file} -i {outdir}/level_matrix/level_13/ -o {outdir}/umi_plot/all_umi_count.tif"
    print(f"cmd:{cmd_str}")
    os.system(cmd_str)
    cmd_str = f"{sys.executable} {pydir}/UMICountDistPlot.py -e {he_file} -i {outdir}/heAuto_level_matrix/subdata/L13_heAuto/ -o {outdir}/umi_plot/roi_umi_count.tif"
    print(f"cmd:{cmd_str}")
    os.system(cmd_str)

    # 提取统计信息
    stat_info(used_args)

    # 统计每个LEVEL下的信息
    used_args['levels'] = levels
    stat_all_level_info(used_args)

    # 打包BSTViewer项目目录
    pack_bstviewer_project(used_args)


def usage():
    print("======="*10)
    print("Usage:")
    print("1) python AllheStat.py -e ./he_chip.tif -m ./sample_matrix_dir/ -o ./outdir/")
    print("2) python AllheStat.py --he_file ./he_chip.tif --matrix_dir ./sample_matrix_dir/ --outdir ./outdir/")
    print("3) python AllheStat.py -h")
    print("4) python AllheStat.py --help")
    print("======="*10)
    exit()



def main():
    # init
    short_opts = 'he:m:o:'
    long_opts = ['help', 'he_file=', 'matrix_dir=', 'outdir=']
    args_names = [None, 'he_file', 'matrix_dir', 'outdir']

    # 生成required_options与opts_2_names
    ss = short_opts.replace(':','')
    required_options = []
    opts_2_names = {}
    for i in range(len(args_names)):
        if args_names[i] is None:
            continue
        else:
            short_o = '-' + ss[i]
            long_o = '--' + long_opts[i].replace('=','')
            required_options.append([short_o,long_o])
            opts_2_names[short_o] = args_names[i]
            opts_2_names[long_o] = args_names[i]

    # getopt
    options_dict = {}
    used_args = {}
    options, args = getopt.getopt(sys.argv[1:], short_opts, long_opts)
    for name, value in options:
        if name not in options_dict.keys():
            options_dict[name] = value
        if name in opts_2_names.keys():
            used_args[opts_2_names[name]] = value
    print(used_args)

    if '-h' in options_dict.keys() or '--help' in options_dict.keys():
        usage()

    # 检查必需提供的参数是否被提供，没有就提示一下，并打印使用说明
    for short_o, long_o in required_options:
        if short_o not in options_dict.keys() and long_o not in options_dict.keys():
            print(f"{short_o} or {long_o} must exist")
            usage()

    do_something(used_args)



if __name__ == "__main__":
    main()








