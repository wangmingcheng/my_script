#!/usr/bin/perl -w
# 
# Copyright (c) BIO_MARK 2021
# Writer:         Dengdj <dengdj@biomarker.com.cn>
# Program Date:   2021
# Modifier:       Dengdj <dengdj@biomarker.com.cn>
# Last Modified:  2021
my $ver="1.6";

use strict;
use Getopt::Long;
use Data::Dumper;
use FindBin qw($Bin $Script);
use File::Basename qw(basename dirname);

#####################

my %opts;
GetOptions(\%opts,"f=s","b=s","o=s","s=s","h");

#&help()if(defined $opts{h});
if(!defined($opts{f}) || !defined($opts{b}) || !defined($opts{s}) || !defined($opts{o}) || defined($opts{h}))
{
	print <<"	Usage End.";
	Description:
		
		Version: $ver
		   v1.5: flu file change to 18-cols.
		   v1.6: add barcode.tsv outfile.

	Usage:

		-f           flu data file                     <infile>     must be given
		-b           barcode index file                <infile>     must be given
		-s           seq barcode file                  <infile>     must be given
		-o           result file                       <outfile>    must be given
		-h           Help document

	Usage End.

	exit;
}

###############Time
my $Time_Start;
$Time_Start = sub_format_datetime(localtime(time()));
&show_log("Start Time :[$Time_Start]");
################
$| = 1 ;
## get parameters
my $bcindexfile = $opts{b} ;
my $flufile = $opts{f} ;
my $seqbcfile = $opts{s} ;
my $outfile = $opts{o} ;

## reading barcode index file
my %hindex = ();
my %hindex2flu = ();
&show_log("start get barcode index");
&get_barcode_index($bcindexfile, \%hindex, \%hindex2flu);

## count barcode diff
my %hbc_diff = ();
my %hdiff2bc = ();
&count_bc_diff(\%hindex, \%hbc_diff, \%hdiff2bc);
#&count_mini_diff(\%hbcindex);

## change to flu
#my %hseqflu = ();
#my %hseq_part = ();
#&show_log("start change seqbc2flu");
#&change_seqbc2flu(\%hseqbc, \%hindex2flu, \%hseqflu, \%hseq_part);

## reading flufile
my %hflu = ();
my %hdup = ();
my %hflu_pos = ();
my %hsim_flu = ();
my %hflu_part = ();
my %hlink1 = ();
my %hlink2 = ();
&show_log("start get flu info");
&get_flu_info($flufile, \%hflu, \%hdup, \%hflu_pos, \%hsim_flu, \%hflu_part, \%hlink1, \%hlink2);

## get dist
my %hdist = ();
my %hdist2flu = ();
&count_bc_flu_dist(\%hflu_part, \%hindex, \%hdist, \%hdist2flu);

## reading seq barcode file
my %hseqbc = ();
&show_log("start reading seq barcode");
&reading_seq_barcode($seqbcfile, \%hseqbc);

## decode flu
my %hbcflu = ();
&show_log("start decode bc flu");
&decode_bc_flu(\%hseqbc, \%hindex2flu, \%hflu_part, \%hlink1, \%hlink2, \%hdist, \%hdist2flu, \%hsim_flu, \%hbcflu);

## decode barcode
#my %hbcflu = ();
#&show_log("start decode barcode");
#&decode_barcode(\%hflu, \%hdup, \%hsim_flu, \%hflu_pos, \%hseqflu, \%hbcflu);

## decode flu
#my %hbcflu = ();
#&decode_flu(\%hflu, \%hdup, \%hbcindex, \%hseqflu, \%hbcflu);

## out put
&show_log("start output");
&output_result(\%hbcflu, \%hseqbc, \%hdup, \%hflu_pos, $outfile);

###############Time
my $Time_End;
$Time_End = sub_format_datetime(localtime(time()));
&show_log("End Time :[$Time_End]");

###############Subs
sub sub_format_datetime {#Time calculation subroutine
    my($sec, $min, $hour, $day, $mon, $year, $wday, $yday, $isdst) = @_;
	$wday = $yday = $isdst = 0;
    sprintf("%4d-%02d-%02d %02d:%02d:%02d", $year+1900, $mon+1, $day, $hour, $min, $sec);
}

sub ABSOLUTE_DIR
{ #$pavfile=&ABSOLUTE_DIR($pavfile);
	my $cur_dir=`pwd`;
	$cur_dir =~ s/\n$//;
	my ($in)=@_;
	my $return="";
	
	if(-f $in)
	{
		my $dir=dirname($in);
		my $file=basename($in);
		chdir $dir;$dir=`pwd`;
		$dir =~ s/\n$// ;
		$return="$dir/$file";
	}
	elsif(-d $in)
	{
		chdir $in;$return=`pwd`;
		$return =~ s/\n$// ;
	}
	else
	{
		warn "Warning just for file and dir [$in]\n";
		exit;
	}
	
	chdir $cur_dir;
	return $return;
}

# &show_log("txt")
sub show_log()
{
	my ($txt) = @_ ;
	my $time = time();
	my $Time = &sub_format_datetime(localtime($time));
	print "$Time:\t$txt\n" ;
	return ($time) ;
}

#&run_or_die($cmd);
sub run_or_die()
{
	my ($cmd) = @_ ;
	my $start_time = &show_log($cmd);
	my $flag = system($cmd) ;
	if ($flag != 0){
		my $end_time = &show_log("Error: command fail: $cmd");
		&show_log("Elaseped time: ".($end_time - $start_time)."s\n");
		exit(1);
	}
	my $end_time = &show_log("done.");
	&show_log("Elaseped time: ".($end_time - $start_time)."s\n");
	return ;
}

## qsub
sub qsub()
{
	my ($shfile, $maxproc) = @_ ;
	my $dir = dirname($shfile) ;
	my $cmd = "cd $dir && sh /share/nas2/genome/bmksoft/tool/qsub_sge_plus/v1.0/qsub_sge.plus.sh --maxproc $maxproc --reqsub --independent $shfile" ;
	&run_or_die($cmd);

	return ;
}

## qsub_mult($shfile, $max_proc, $job_num)
sub qsub_mult()
{
	my ($shfile, $max_proc, $job_num) = @_ ;
	if ($job_num > 500){
		my @shfiles = &cut_shfile($shfile);
		for my $file (@shfiles){
			&qsub($file, $max_proc);
		}
	}
	else{
		&qsub($shfile, $max_proc) ;
	}
}

#my @shfiles = &cut_shfile($shfile);
sub cut_shfile()
{
	my ($file) = @_ ;
	my @files = ();
	my $num = 0 ;
	open (IN, $file) || die "Can't open $file, $!\n" ;
	(my $outprefix = $file) =~ s/.sh$// ;
	while (<IN>){
		chomp ;
		if ($num % 500 == 0){
			close(OUT);
			my $outfile = "$outprefix.sub_".(int($num/500)+1).".sh" ;
			push @files, $outfile ;
			open (OUT, ">$outfile") || die "Can't creat $outfile, $!\n" ;
		}
		print OUT $_, "\n" ;
		$num ++ ;
	}
	close(IN);
	close(OUT);

	return @files ;
}

#&get_barcode_index($bcindexfile, \%hindex, \%hindex2flu);
sub get_barcode_index()
{
    my ($bcindexfile, $ahindex, $ahindex2flu) = @_ ;

    open (IN, $bcindexfile) || die "$bcindexfile, $!\n" ;
    while(<IN>){
        chomp ;
        next if (m/Index|^\s*$/);
        my ($index, $seq, @arr) = split ;
        my $str ;
        my $value ;
        for (my $i=0; $i<6; $i++){
            my $cy3 = $arr[$i] ;
            my $cy5 = $arr[$i+6] ;
            if ($cy3 == 1){
                $value = 0 ;
            }
            elsif ($cy5 == 1){
                $value = 1 ;
            }
            else{
                $value = 2 ;
            }
            if ($cy3 && $cy5){
                print "error: $_\n" ;
                exit(1);
            }
            $str .= $value ;
        }
        $ahindex->{$str} = $index ;
        $ahindex2flu->{$index} = $str ;
    }
    close(IN);

    return ;
}

#&get_candi_index(\%hbcindex, \%hcandi);
sub get_candi_index()
{
    my ($ahindex, $ahcandi) = @_ ;

    for my $str (keys %{$ahindex}){
        for (my $i=0; $i<length($str); $i++){
            my $new_str = $str ;
            $new_str =~ substr($new_str, $i, 1, "-");
            push @{$ahcandi->{$new_str}}, $ahindex->{$str} ;
        }
    }

    return ;
}

#&count_bc_diff(\%hindex, \%hbc_diff, \%hdiff2bc);
sub count_bc_diff()
{
    my ($ahindex, $ahbc_diff, $ahdiff2bc) = @_ ;

    my @strs = keys %{$ahindex} ;
    for (my $i=0; $i<@strs-1; $i++){
        my $s1 = $strs[$i] ;
        my $index1 = $ahindex->{$s1} ;
        for (my $j=$i+1; $j<@strs; $j++){
            my $s2 = $strs[$j] ;
            my $index2 = $ahindex->{$s2} ;
            my $diff = &count_diff($s1, $s2);
            $ahbc_diff->{$s1}{$s2} = $diff ;
            $ahbc_diff->{$s2}{$s1} = $diff ;
            push @{$ahdiff2bc->{$diff}{$index1}}, $index2 ;
            push @{$ahdiff2bc->{$diff}{$index2}}, $index1 ;
        }
    }

    return ;
}

#&count_mini_diff(\%hbcindex);
sub count_mini_diff()
{
    my ($ahindex) = @_ ;

    my @strs = keys %{$ahindex} ;
    my $min_diff = 9 ;
    my ($min_s1, $min_s2) ;
    for (my $i=0; $i<@strs-1; $i++){
        my $s1 = $strs[$i] ;
        for (my $j=$i+1; $j<@strs; $j++){
            my $s2 = $strs[$j] ;
            my $diff = &count_diff($s1, $s2);
            if ($diff < $min_diff){
                $min_diff = $diff ;
                $min_s1 = $s1 ;
                $min_s2 = $s2 ;
            }
        }
    }
    print "mindiff: $min_diff\n" ;
    print "min_s1: $min_s1\t", $ahindex->{$min_s1}, "\n" ;
    print "min_s2: $min_s2\t", $ahindex->{$min_s2}, "\n" ;

    return ;
}
#my $diff = &count_diff($s1, $s2);
sub count_diff()
{
    my ($s1, $s2) = @_ ;

    my $len = length($s1) ;
    my $diff = 0 ;
    for (my $i=0; $i<$len; $i++){
        if (substr($s1, $i, 1) != substr($s2, $i, 1)){
            $diff++ ;
        }
    }

    return($diff) ;
}

#&get_flu_info($flufile, \%hflu, \%hdup, \%hflu_pos, \%hsim_flu, \%hflu_part, \%hlink1, \%hlink2);
sub get_flu_info()
{
    my ($flufile, $ahflu, $ahdup, $ahflu_pos, $ahsim_flu, $ahflu_part, $ahlink1, $ahlink2) = @_ ;

    open (IN, $flufile) || die "$flufile, $!\n" ;
    my $index = 0 ;
    while(<IN>){
        chomp ;
        next if (m/^\#|^\s*$/);
        $index++ ;
        my ($str) = split ;
        my $sim = substr($str, 0, 18) ;
        if (defined $ahflu->{$str}){
            $ahdup->{$str} = 1;
        }
        else{
            $ahflu->{$str} = $index ;
        }
        my $pos = &change2pos($index);
        $ahflu_pos->{$str} = $pos ;
        $ahsim_flu->{$sim} = $str ;
        if ($sim =~ m/(\d{6})(\d{6})(\d{6})/){
            push @{$ahflu_part->{$1}}, $str ;
            push @{$ahflu_part->{$2}}, $str ;
            push @{$ahflu_part->{$3}}, $str ;
            $ahlink1->{$1}{$2} = 1 ;
            $ahlink2->{$2}{$3} = 1 ;
        }
    }
    close(IN);

    return ;
}

#my $pos = &change2pos($index);
sub change2pos()
{
    my ($index) = @_ ;

    $index -= 1 ;

    my $block = int($index/30/35) ;
    my $block_row = int($block/46) ;
    my $block_col = $block % 46 ;

    my $pos = $index % (30*35);
    my $pos_row = int($pos/30) ;
    my $pos_col = $pos % 30 ;

    return("$block_row\t$block_col\t$pos_row\t$pos_col");
}

#&count_bc_flu_dist(\%hflu_part, \%hindex, \%hdist, \%hdist2flu);
sub count_bc_flu_dist()
{
    my ($ahflu_part, $ahindex, $ahdist, $ahdist2flu) = @_ ;

    for my $s1 (keys %{$ahflu_part}){
        for my $s2 (keys %{$ahindex}){
            my $diff = &count_diff($s1, $s2) ;
            $ahdist->{$s2}{$s1} = $diff ;
            push @{$ahdist2flu->{$diff}{$s2}}, $s1 ;
        }
    }

    return ;
}

#&decode_bc_flu(\%hseqbc, \%hindex2flu, \%hflu_part, \%hlink1, \%hlink2, \%hdist, \%hdist2flu, \%hsim_flu, \%hbcflu);
sub decode_bc_flu()
{
    my ($ahseqbc, $ahindex2flu, $ahflu_part, $ahlink1, $ahlink2, $ahdist, $ahdist2flu, $ahsim_flu, $ahbcflu) = @_ ;

    for my $type (keys %{$ahseqbc}){
        my @bcs = split /\-/, $type ;
        #print "@bcs\n" ;
        if (scalar @bcs > 2){
            my @candis = ();
            my @bc_strs = ();
            for (my $i=0; $i<@bcs; $i++){
                my $index = (split /\_/, $bcs[$i])[1] ;
                my $str = $ahindex2flu->{$index} ;
                push @bc_strs, $str ;
                my @candi = ();
                #print "$str\n" ;
                #print Dumper $ahdist2flu, "\n" ;
                if (defined $ahdist2flu->{0}{$str}){
                    push @candi, @{$ahdist2flu->{0}{$str}} ;
                }
                if (defined $ahdist2flu->{1}{$str}){
                    push @candi, @{$ahdist2flu->{1}{$str}} ;
                }
                $candis[$i] = \@candi ;
            }
            my %hcandi = ();
            &judge_flu_combine_type(\@candis, $ahsim_flu, \@bc_strs, $ahdist, $ahlink1, \%hcandi);
            my @diffs = sort {$a<=>$b} keys %hcandi ;
            if (scalar @diffs > 0){
                my @strs = @{$hcandi{$diffs[0]}} ;
                if (scalar(@strs) == 1){
                    $ahbcflu->{$type} = $strs[0] ;
                }
                else{
                    $ahbcflu->{$type} = "mult" ;
                }
            }
            else{
                $ahbcflu->{$type} = "null" ;
            }
        }
        else{
            $ahbcflu->{$type} = "part" ;
        }
    }

    return ;
}

#&judge_flu_combine_type(\@candis, $ahsim_flu, \@bc_strs, $ahdist, $ahlink1, \%hcandi);
sub judge_flu_combine_type()
{
    my ($acandis, $ahsim_flu, $abcs, $ahdist, $ahlink1, $ahcandi) = @_ ;

    for (my $i=0; $i<@{$acandis->[0]}; $i++){
        my $d1 = $ahdist->{$abcs->[0]}{$acandis->[0][$i]};
        #print $acandis->[0][$i], "\t", $d1, "\n" ;
        for (my $j=0; $j<@{$acandis->[1]}; $j++){
            next if (!defined $ahlink1->{$acandis->[0][$i]}{$acandis->[1][$j]}) ;
            my $d2 = $ahdist->{$abcs->[1]}{$acandis->[1][$j]};
            for (my $k=0; $k<@{$acandis->[2]}; $k++){
                my $d3 = $ahdist->{$abcs->[2]}{$acandis->[2][$k]};
                my $sum = $d1 + $d2 + $d3 ;
                next if (!defined $ahsim_flu->{$acandis->[0][$i].$acandis->[1][$j].$acandis->[2][$k]}) ;
                my $str = $acandis->[0][$i].$acandis->[1][$j].$acandis->[2][$k] ;
                push @{$ahcandi->{$sum}}, $ahsim_flu->{$str} ;
            }
        }
    }

    return ;
}

#&decode_barcode(\%hflu, \%hdup, \%hsim_flu, \%hflu_pos, \%hseqflu, \%hbcflu);
sub decode_barcode()
{
    my ($ahflu, $ahdup, $ahsim_flu, $ahflu_pos, $ahseqflu, $ahbcflu) = @_ ;

    for my $flu (keys %{$ahseqflu}){
        my $type = $ahseqflu->{$flu} ;
        my $str = &judge_flu_str($flu, $ahsim_flu);
        if (!defined $str){
            print "$flu\t$type\n" ;
            if (defined $ahsim_flu->{$flu}){
                print "ok\t", $ahsim_flu->{$flu}, "\n" ;
            }
            die ;
        }
        if ($str =~ m/\d+/){
            if (defined $ahdup->{$str}){
                $ahbcflu->{$type} = "-1\t-1\t-1\t-1" ;
            }
            else{
                $ahbcflu->{$type} = $ahflu_pos->{$str} ;
            }
        }
        else{
            $ahbcflu->{$type} = "-1\t-1\t-1\t-1" ;
        }
    }

    return ;
}

#my $str = &judge_flu_str($flu, $ahsim_flu);
sub judge_flu_str()
{
    my ($flu, $ahsim_flu) = @_ ;

    my $str = "" ;
    if (defined $ahsim_flu->{$flu}){
        $str = $ahsim_flu->{$flu} ;
    }
    else{
        my %hflu = ();
        my $flag = 0 ;
        for my $s (keys %{$ahsim_flu}){
            my $score = &count_flu_score($s, $flu);
            next if ($score < 12) ;
            $hflu{$s} = $score ;
            $flag = 1 ;
        }
        if ($flag == 0){
            $str = "Null" ;
        }
        else{
            my @flus = sort {$hflu{$b}<=>$hflu{$a}} keys %hflu ;
            if (scalar(@flus) == 1){
                $str = $ahsim_flu->{$flus[0]} ;
            }
            else{
                if ($hflu{$flus[0]} > $hflu{$flus[1]}){
                    $str = $ahsim_flu->{$flus[0]} ;
                }
                else{
                    $str = "mult" ;
                }
            }
        }
    }

    return($str);
}

#&decode_flu(\%hflu, \%hdup, \%hbcindex, \%hseqflu, \%hbcflu);
sub decode_flu()
{
    my ($ahflu, $ahdup, $ahbcindex, $ahseqflu, $ahbcflu) = @_ ;

    for my $str (keys %{$ahflu}){
        next if (defined $ahdup->{$str}) ;
        my $bc_type = "" ;
        if ($str =~ m/(\d)(\d{6})(\d{6})(\d{6})(\d)/){
            my ($sf, $b1, $b2, $b3, $ef) = ($1, $2, $3, $4, $5) ;
            my $s = $b1.$b2.$b3 ;
            my $type = &judge_flu_type($s, $ahbcindex, $ahseqflu);
            if ($type =~ m/bc/){
                $bc_type = $type ;
            }
        }
        $hbcflu{$str} = $bc_type ;
    }

    return ;
}

#&judge_flu_type($s, $ahbcindex, $ahseqflu);
sub judge_flu_type()
{
    my ($s, $ahbcindex, $ahseqflu) = @_ ;

    my $type ;
    if (defined $ahseqflu->{$s}){
        $type = $ahseqflu->{$s} ;
    }
    else{
        my %hflu = ();
        my $flag = 0 ;
        for my $flu (keys %{$ahseqflu}){
            my $score = &count_flu_score($s, $flu);
            next if ($score < 12) ;
            $hflu{$flu} = $score ;
            $flag = 1 ;
        }
        if ($flag == 0){
            $type = "Null" ;
        }
        else{
            my @flus = sort {$hflu{$b}<=>$hflu{$a}} keys %hflu ;
            if (scalar(@flus) == 1){
                $type = $ahseqflu->{$flus[0]} ;
            }
            else{
                if ($hflu{$flus[0]} > $hflu{$flus[1]}){
                    $type = $ahseqflu->{$flus[0]} ;
                }
                else{
                    $type = "mult" ;
                }
            }
        }
    }

    return($type);
}

#my $score = &count_flu_score($s, $flu);
sub count_flu_score()
{
    my ($s1, $s2) = @_ ;

    my $sum = 0 ;
    for (my $i=0; $i<18; $i++){
        if (substr($s1, $i, 1) == substr($s2, $i, 1)){
            $sum++ ;
        }
    }

    return($sum);
}

#my ($index, @candi) = &judge_barcode($s, $ahbcindex, $ahcandi, $ahdiff2bc);
sub judge_barcode()
{
    my ($str, $ahindex, $ahcandi, $ahdiff2bc) = @_ ;

    my $len = length($str) ;
    my $index = "-1" ;
    my @candi = ();
    if (defined $ahindex->{$str}){
        $index = $ahindex->{$str};
        @candi = @{$ahcandi->{'1'}{$index}};
    }
    else{
        for (my $i=0; $i<$len; $i++){
            my $new_str = $str ;
            substr($new_str, $i, 1, "-") ;
            if (defined $ahindex->{$new_str}){
                push @candi, $ahindex->{$new_str} ;
            }
        }
    }

    return($index, @candi);
}

#&reading_seq_barcode($seqbcfile, \%hseqbc);
sub reading_seq_barcode()
{
    my ($seqbcfile, $ahseqbc) = @_ ;

    open (IN, $seqbcfile) || die "$seqbcfile, $!\n" ;
    while(<IN>){
        chomp ;
        my ($id, $type) = split ;
        if ($type =~ m/Null/i){
            push @{$ahseqbc->{Null}}, $id ;
        }
        else{
            push @{$ahseqbc->{$type}}, $id ;
        }
    }
    close(IN);

    return ;
}

#&change_seqbc2flu(\%hseqbc, \%hindex2flu, \%hseqflu, \%hseq_part);
sub change_seqbc2flu()
{
    my ($ahseqbc, $ahindex2flu, $ahseqflu, $ahseq_part) = @_ ;

    for my $type (keys %{$ahseqbc}){
        my @bcs = split /\-/, $type ;
        my $flus = "" ;
        if (scalar(@bcs) > 2){
            for (my $i=0; $i<@bcs; $i++){
                my $bc = (split /\_/, $bcs[$i])[1] ;
                my $flu = $ahindex2flu->{$bc} ;
                $flus .= $flu ;
            }
            $ahseqflu->{$flus} = $type ;
        }
        else{
            $ahseq_part->{$type} = $ahseqbc->{$type} ;
        }
    }

    return ;
}

#&output_result(\%hbcflu, \%hseqbc, \%hdup, \%hflu_pos, $outfile);
sub output_result()
{
    my ($ahbcflu, $ahseqbc, $ahdup, $ahflu_pos, $outfile) = @_ ;

    open (OUT, ">$outfile.pos") || die "$outfile.pos, $!\n" ;
    my %hbc = ();
    for my $type (keys %{$ahbcflu}){
        my $str = $ahbcflu->{$type} ;
        if ($str =~ m/\d+/){
            my $pos = $ahflu_pos->{$str} ;
            my $flag = 0 ;
            if (defined $ahdup->{$str}){
                $pos = "-1\t-1\t-1\t-1" ;
                $flag = 1 ;
            }
            for (my $i=0; $i<@{$ahseqbc->{$type}}; $i++){
                my $id = $ahseqbc->{$type}[$i] ;
                print OUT "$id\t$pos\t$type" ;
                if ($flag){
                    print OUT "\tDup\n" ;
                }
                else{
                    print OUT "\t0\n" ;
                    $hbc{$type}++ ;
                }
            }
        }
        else{
            my $pos = "-1\t-1\t-1\t-1" ;
            for (my $i=0; $i<@{$ahseqbc->{$type}}; $i++){
                my $id = $ahseqbc->{$type}[$i] ;
                print OUT "$id\t$pos\t$type\tU\n" ;
            }
        }
    }
    close(OUT) ;

    open (OUT, ">$outfile.barcode.tsv") || die "$outfile.barcode.tsv, $!\n" ;
    for my $type (sort keys %hbc){
        print OUT "$type\n" ;
    }
    close(OUT);

    return ;
}

