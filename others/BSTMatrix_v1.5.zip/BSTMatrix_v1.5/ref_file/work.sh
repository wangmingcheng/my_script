perl ../tools/get_uniq_kmer_v1.3.pl bc1.fa  bc2.fa  bc3.fa ref_seq_BCV2.fa BCV2.kmerfile
