
import numpy
from distutils.core import setup, Extension
from Cython.Build import cythonize

setup(ext_modules=cythonize(['cellranger/bisect.pyx']),
     include_dirs=[numpy.get_include()])


