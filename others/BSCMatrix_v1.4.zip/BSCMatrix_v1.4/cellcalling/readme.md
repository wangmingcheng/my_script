# 输入
查看帮助文档：`python ../__main__.py --help`

```
/share/nas1/wangjs/opt/miniconda3/envs/py39/bin/python __main__.py --help
usage: [-h] --matrix MATRIX [--expect-cells EXPECT_CELLS] [--basedir BASEDIR]

optional arguments:
  -h, --help            show this help message and exit
  --matrix MATRIX, -m MATRIX
                        raw feature barcode matrix
  --expect-cells EXPECT_CELLS, -e EXPECT_CELLS
                        number of expected cells
  --basedir BASEDIR, -d BASEDIR
                        output direction
```
其中，--matrix是原始表达矩阵，--expect-cells是期望的细胞数，一般如果比确定的期望细胞数，建议设定此值，默认是3000，默认值可以应付大多数情况，--basedir输出目录

# 输出
1. 过滤后表达矩阵:filtered_feature_bc_matrix
2. rank_barcode_umi.html
3. qc指标：qc.txt
4. 运行结果参考test目录下的示例


# 安装及使用
test目录下是运行的例子，假设实在test目录下运行，有以下几种情况：
1. 如果是在12集群上运行可以直接使用一下命令：
`/share/nas1/wangjs/opt/miniconda3/envs/py39/bin/python ../__main__.py -m /share/nas1/wangjs/project/tmpdata/ZYMT/raw_feature_bc_matrix -d ZYMT -e 3000`

2. 如果在其他地方运行，或者不用1中指定的python：需要安装依赖的包，目前没有整理依赖的包目录，也不能自动安装，只能在运行过程中缺啥安装啥，另外如果系统版本或python版本不是3.9，最好在运行前先运行(cellcalling目录下)：`python setup.py build_ext -i`，这样会依据系统和环境重新编译用到的动态库，不编译一般也可以

3. 也可以作为模块运行：`from cells import callcells`，具体可以参考__main__.py的代码，要保证此目录放在python的查找目录下，比如设置PYTHONPATH环境变量等

# 说明
1. 目前采用的方法与cellranger相比是做了简化的，因此结果会有少量差别，可以在后续的版本中改进



