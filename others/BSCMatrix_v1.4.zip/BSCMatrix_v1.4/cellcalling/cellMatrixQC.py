import pandas as pd
import sys
import getopt


def median_num_stat(matrix_file, skiprows=3):
    df = pd.read_csv(matrix_file, compression='gzip', sep=' ', names=['gene', 'supspot', 'umi'], skiprows=skiprows,
                     header=None)
    print(df.head())
    supspot_num = df['supspot'].value_counts().shape[0]
    gene_num = df['gene'].value_counts().shape[0]
    median_gene_num = df['supspot'].value_counts().median()
    median_umi_num = df['umi'].astype(float).groupby(df['supspot']).sum().median()
    return([supspot_num, median_gene_num, median_umi_num, gene_num])
    pass

def sequencing_saturation(infile, iszip=True):
    if iszip:
        df = pd.read_csv(infile, compression='gzip', sep='\t', names=['bc_name', 'umi_seq', 'read_count'], header=None)
    else:
        df = pd.read_csv(infile, sep='\t', names=['bc_name', 'umi_seq', 'read_count'], header=None)

    # one_count = df['read_count'] == 1
    # rate = 1.0 - sum(one_count) / df.shape[0]
    one_count = sum(df[df['read_count'] == 1]['read_count'])
    rate = 1.0 - one_count / df.shape[0]
    # print(f"rate:{rate}")
    return rate
    pass

def read_in_cell(bc_file, bc_umi_read_file):
    bc_umi_read_df = pd.read_csv(bc_umi_read_file, compression='gzip', sep='\t', names=['bc_name', 'umi_seq', 'read_count'], header=None)
    bc_df = pd.read_csv(bc_file, compression='gzip', sep='\t', names=['bc_name'], header=None)
    sum_read = sum(bc_umi_read_df['read_count'])
    cell_read = sum(bc_umi_read_df[bc_umi_read_df['bc_name'].isin(bc_df['bc_name'])]['read_count'])
    rate = cell_read / sum_read
    print(f"cell rate:{rate}")
    return rate
    pass


def do_something(used_args):
    # 打开输出文件
    with open(used_args['outfile'], 'w') as fp:
        # 统计过滤后的表达量矩阵
        matrix_file = f'{used_args["filter_matrix"]}/matrix.mtx.gz'
        print(f"file:{matrix_file}")
        nums = median_num_stat(matrix_file=matrix_file)
        fp.write(f"Estimated Number of Cells\t{nums[0]}\n")
        fp.write(f"Median Genes per Cell\t{nums[1]}\n")
        fp.write(f"Total Genes Detected\t{nums[3]}\n")
        fp.write(f"Median UMI Counts per Cell\t{nums[2]}\n")
        # 统计测序饱和度
        bc_umi_read_file = f'{used_args["raw_matrix"]}/bc_umi_read.tsv.gz'
        rate = sequencing_saturation(bc_umi_read_file, iszip=True)
        fp.write(f"Sequencing Saturation\t{rate}\n")
        # 统计在细胞中的read占比
        filter_bc_file = f"{used_args['filter_matrix']}/barcodes.tsv.gz"
        cell_rate = read_in_cell(filter_bc_file, bc_umi_read_file)
        fp.write(f"Fraction Reads in Cells\t{cell_rate}\n")
    pass


def usage():
    print("======="*10)
    print("Usage:")
    print("1) python cellMatrixQC.py -r ./raw_matrix/dir/ -f ./filter_matrix/dir/ -o stat.txt")
    print("2) python cellMatrixQC.py --raw_matrix ./test.tif --filter_matrix ./outdir/ --outfile stat.txt")
    print("3) python cellMatrixQC.py -h")
    print("4) python cellMatrixQC.py --help")
    print("======="*10)
    exit()



def main():
    # init
    short_opts = 'hr:f:o:'
    long_opts = ['help', 'raw_matrix=', 'filter_matrix=', 'outfile=']
    args_names = [None, 'raw_matrix', 'filter_matrix', 'outfile']

    # 生成required_options与opts_2_names
    ss = short_opts.replace(':','')
    required_options = []
    opts_2_names = {}
    for i in range(len(args_names)):
        if args_names[i] is None:
            continue
        else:
            short_o = '-' + ss[i]
            long_o = '--' + long_opts[i].replace('=','')
            required_options.append([short_o,long_o])
            opts_2_names[short_o] = args_names[i]
            opts_2_names[long_o] = args_names[i]

    # getopt
    options_dict = {}
    used_args = {}
    options, args = getopt.getopt(sys.argv[1:], short_opts, long_opts)
    for name, value in options:
        if name not in options_dict.keys():
            options_dict[name] = value
        if name in opts_2_names.keys():
            used_args[opts_2_names[name]] = value
    print(used_args)

    if '-h' in options_dict.keys() or '--help' in options_dict.keys():
        usage()

    # 检查必需提供的参数是否被提供，没有就提示一下，并打印使用说明
    for short_o, long_o in required_options:
        if short_o not in options_dict.keys() and long_o not in options_dict.keys():
            print(f"{short_o} or {long_o} must exist")
            usage()

    do_something(used_args)



if __name__ == "__main__":
    main()
    pass



