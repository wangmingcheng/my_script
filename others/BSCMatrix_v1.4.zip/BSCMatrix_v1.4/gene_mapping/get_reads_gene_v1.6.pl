#!/usr/bin/perl -w
# 
# Copyright (c) BIO_MARK 2021
# Writer:         Dengdj <dengdj@biomarker.com.cn>
# Program Date:   2021
# Modifier:       Dengdj <dengdj@biomarker.com.cn>
# Last Modified:  2021
my $ver="1.6";

use strict;
use Getopt::Long;
use Data::Dumper;
use FindBin qw($Bin $Script);
use File::Basename qw(basename dirname);

#####################

my %opts;
GetOptions(\%opts,"i=s","g=s","o=s","h" );

#&help()if(defined $opts{h});
if(!defined($opts{i}) || !defined($opts{g}) || !defined($opts{o}) || defined($opts{h}))
{
	print <<"	Usage End.";
	Description:
		
		Version: $ver
		   v1.2: change infile to bam.
		         change to use cds instead of gene.
		   v1.3: add gene map output.
		   v1.4: add unmap gene reads output.
		   v1.5: do not consider cds map.
		         consider ncRNA_gene etc.(col 3 ~/gene/)
		   v1.6: memory optimization.

	Usage:

		-i           reads mapping bam file                <infile>     must be given
		-g           gene gff file                         <infile>     must be given
		-o           result file                           <outfile>    must be given
		-h           Help document

	Usage End.

	exit;
}

###############Time
my $Time_Start;
$Time_Start = sub_format_datetime(localtime(time()));
&show_log("Start Time :[$Time_Start]");
################
$| = 1 ;
## get parameters
my $bamfile = $opts{i} ;
my $gfffile = $opts{g} ;
my $outfile = $opts{o} ;

## get gene info
my %hgene = ();
my %hcds = ();
&get_gene_info($gfffile, \%hgene, \%hcds);

## get reads mapping info
my %hid = ();
my %hid_gene = ();
my %hunmap_id = ();
&get_reads_mapping_info($bamfile, \%hgene, \%hid, \%hid_gene, \%hunmap_id);

## get reads gene
#my %hid = ();
#my %hid_gene = ();
#my %hunmap_id = ();
#&get_reads_gene(\%hgene, \%hcds, \%hmap, \%hid, \%hid_gene, \%hunmap_id);

## out put
&out_put(\%hid, \%hid_gene, \%hunmap_id, $outfile);

###############Time
my $Time_End;
$Time_End = sub_format_datetime(localtime(time()));
&show_log("End Time :[$Time_End]");

###############Subs
sub sub_format_datetime {#Time calculation subroutine
    my($sec, $min, $hour, $day, $mon, $year, $wday, $yday, $isdst) = @_;
	$wday = $yday = $isdst = 0;
    sprintf("%4d-%02d-%02d %02d:%02d:%02d", $year+1900, $mon+1, $day, $hour, $min, $sec);
}

sub ABSOLUTE_DIR
{ #$pavfile=&ABSOLUTE_DIR($pavfile);
	my $cur_dir=`pwd`;
	$cur_dir =~ s/\n$//;
	my ($in)=@_;
	my $return="";
	
	if(-f $in)
	{
		my $dir=dirname($in);
		my $file=basename($in);
		chdir $dir;$dir=`pwd`;
		$dir =~ s/\n$// ;
		$return="$dir/$file";
	}
	elsif(-d $in)
	{
		chdir $in;$return=`pwd`;
		$return =~ s/\n$// ;
	}
	else
	{
		warn "Warning just for file and dir [$in]\n";
		exit;
	}
	
	chdir $cur_dir;
	return $return;
}

# &show_log("txt")
sub show_log()
{
	my ($txt) = @_ ;
	my $time = time();
	my $Time = &sub_format_datetime(localtime($time));
	print "$Time:\t$txt\n" ;
	return ($time) ;
}

#&run_or_die($cmd);
sub run_or_die()
{
	my ($cmd) = @_ ;
	my $start_time = &show_log($cmd);
	my $flag = system($cmd) ;
	if ($flag != 0){
		my $end_time = &show_log("Error: command fail: $cmd");
		&show_log("Elaseped time: ".($end_time - $start_time)."s\n");
		exit(1);
	}
	my $end_time = &show_log("done.");
	&show_log("Elaseped time: ".($end_time - $start_time)."s\n");
	return ;
}

## qsub
sub qsub()
{
	my ($shfile, $maxproc) = @_ ;
	my $dir = dirname($shfile) ;
	my $cmd = "cd $dir && sh /share/nas2/genome/bmksoft/tool/qsub_sge_plus/v1.0/qsub_sge.plus.sh --maxproc $maxproc --reqsub --independent $shfile" ;
	&run_or_die($cmd);

	return ;
}

## qsub_mult($shfile, $max_proc, $job_num)
sub qsub_mult()
{
	my ($shfile, $max_proc, $job_num) = @_ ;
	if ($job_num > 500){
		my @shfiles = &cut_shfile($shfile);
		for my $file (@shfiles){
			&qsub($file, $max_proc);
		}
	}
	else{
		&qsub($shfile, $max_proc) ;
	}
}

#my @shfiles = &cut_shfile($shfile);
sub cut_shfile()
{
	my ($file) = @_ ;
	my @files = ();
	my $num = 0 ;
	open (IN, $file) || die "Can't open $file, $!\n" ;
	(my $outprefix = $file) =~ s/.sh$// ;
	while (<IN>){
		chomp ;
		if ($num % 500 == 0){
			close(OUT);
			my $outfile = "$outprefix.sub_".(int($num/500)+1).".sh" ;
			push @files, $outfile ;
			open (OUT, ">$outfile") || die "Can't creat $outfile, $!\n" ;
		}
		print OUT $_, "\n" ;
		$num ++ ;
	}
	close(IN);
	close(OUT);

	return @files ;
}

sub sub_normal_dis_ran(){#$average,$standard_deviation
        my ($aver,$stand_dev) = @_ ;
        my $ran1 = rand() ;
        my $ran2 = rand() ;
        my $y = ((-2*log($ran1))**(0.5))*sin(2*3.1415926535*$ran2) ;
        return ($aver + $stand_dev*$y) ;
}

#&get_gene_info($gfffile, \%hgene, \%hcds);
sub get_gene_info()
{
    my ($gfffile, $ahgene, $ahcds) = @_ ;

    open (IN, $gfffile) || die "$gfffile, $!\n" ;
    my $gene_id ;
    while(<IN>){
        chomp ;
        next if (m/^\#|^\s*$/);
        my ($chr, $soft, $type, $start, $end, undef, $ori, $offset, $info) = split ;
        if ($type =~ m/gene/i){
            next if ($type =~ /segment/) ;
            if ($info =~ m/ID=(.*?)\;/){
                $gene_id = $1 ;
            }
            elsif ($info =~ m/ID=([^;]*?)\s*$/){
                $gene_id = $1 ;
            }
            push @{$ahgene->{$chr}}, [$start, $end, $gene_id] ;
        }
        elsif ($type eq 'CDS'){
            push @{$ahcds->{$gene_id}}, [$start, $end] ;
        }
    }
    close(IN);

    for my $chr (keys %{$ahgene}){
        @{$ahgene->{$chr}} = sort {$a->[0]<=>$b->[0]||$a->[1]<=>$b->[1]} @{$ahgene->{$chr}} ;
    }
    for my $gene (keys %{$ahcds}){
        @{$ahcds->{$gene}} = sort {$a->[0]<=>$b->[0]||$a->[1]<=>$b->[1]} @{$ahcds->{$gene}} ;
    }

    return ;
}

#&get_reads_mapping_info($bamfile, \%hgene, \%hid, \%hid_gene, \%hunmap_id);
sub get_reads_mapping_info()
{
    my ($bamfile, $ahgene, $ahid, $ahid_gene, $ahunmap_id) = @_ ;

    my %hindex = ();
    for my $chr (keys %{$ahgene}){
        $hindex{$chr} = 0 ;
    }
    open (IN, "samtools view $bamfile|") || die "$bamfile, $!\n" ;
    while(<IN>){
        chomp ;
        next if (m/^\@/);
        my ($id, $flag, $chr, $start, $mapQ, $cigar, undef, undef, undef, $seq, $qual) = split ;
        my ($maplen, @matchs) = &get_maplen($cigar);
        my $end = $start + $maplen - 1 ;
        for (my $i=0; $i<@matchs; $i++){
            $matchs[$i][0] += $start ;
            $matchs[$i][1] += $start - 1 ;
        }
        my $mapflag = 0 ;
        if (!defined $hindex{$chr}){
            push @{$ahunmap_id->{$id}}, [$chr, @matchs] ;
            next ;
        }
        for (my $i=$hindex{$chr}; $i<@{$ahgene->{$chr}}; $i++){
            my ($g_start, $g_end, $g_id) = @{$ahgene->{$chr}[$i]} ;
            if ($end < $g_start){
                last ;
            }
            elsif ($start <= $g_end){
                my $flag = &judge_gene($g_start, $g_end, \@matchs);
                if ($flag){
                    push @{$ahid_gene->{$id}}, $g_id ;
                    $mapflag = 1 ;
                }
            }
            else{
                $hindex{$chr} = $i ;
                next ;
            }
        }
        if ($mapflag == 0){
            push @{$ahunmap_id->{$id}}, [$chr, @matchs] ;
        }
    }
    close(IN);

    return ;
}

#my ($maplen, @matchs) = &get_maplen($cigar);
sub get_maplen()
{
    my ($cigar) = @_ ;

    my $len = 0 ;
    my @matchs = ();
    while($cigar =~ m/(\d+)([a-zA-Z])/g){
        my ($num, $type) = ($1, $2) ;
        if ($type eq 'M' || $type eq '='){
            my $start = $len ;
            $len += $num ;
            my $end = $len ;
            push @matchs, [$start, $end] ;
        }
        elsif ($type eq 'N' || $type eq 'D' || $type eq 'X'){
            $len += $num ;
        }
    }

    return($len, @matchs);
}

#&get_reads_gene(\%hgene, \%hcds, \%hmap, \%hid, \%hid_gene, \%hunmap_id);
sub get_reads_gene()
{
    my ($ahgene, $ahcds, $ahmap, $ahid, $ahid_gene, $ahunmap_id) = @_ ;

    open (OUT, ">$outfile") || die "$outfile, $!\n" ;
    for my $chr (keys %{$ahmap}){
        my @gene_region = sort {$a->[0]<=>$b->[0] || $a->[1]<=>$b->[1]} @{$ahgene->{$chr}} ;
        my @reads_region = sort {$a->[0]<=>$b->[0] || $a->[1]<=>$b->[1]} @{$ahmap->{$chr}} ;
        my $index = 0 ;
        for (my $i=0; $i<@reads_region; $i++){
            my ($r_start, $r_end, $r_id, @r_matchs) = @{$reads_region[$i]} ;
            my $mapflag = 0 ;
            for (my $j=$index; $j<@gene_region; $j++){
                my ($g_start, $g_end, $g_id) = @{$gene_region[$j]} ;
                if ($r_end < $g_start){
                    last ;
                }
                elsif ($r_start <= $g_end){
                    #my $flag = &judge_cds($ahcds->{$g_id}, \@r_matchs);
                    #if ($flag){
                    #    push @{$ahid->{$r_id}}, $g_id ;
                    #}
                    my $flag = &judge_gene($g_start, $g_end, \@r_matchs);
                    if ($flag){
                        push @{$ahid_gene->{$r_id}}, $g_id ;
                        $mapflag = 1 ;
                    }
                }
                else{
                    $index = $j ;
                    next ;
                }
            }
            if ($mapflag == 0){
                push @{$ahunmap_id->{$r_id}}, [$chr, @r_matchs] ;
            }
        }
    }
    close(OUT) ;

    return ;
}

#my $flag = &judge_cds($ahcds->{$g_id}, \@r_matchs);
sub judge_cds()
{
    my ($acds, $ar_matchs) = @_ ;

    my $index = 0 ;
    for (my $i=0; $i<@{$acds}; $i++){
        my ($c_start, $c_end) = @{$acds->[$i]} ;
        for (my $j=$index; $j<@{$ar_matchs}; $j++){
            my ($r_start, $r_end) = @{$ar_matchs->[$j]} ;
            if ($r_end < $c_start){
                $index = $j ;
                next ;
            }
            elsif ($r_start <= $c_end){
                return(1);
            }
            else{
                last ;
            }
        }
    }

    return(0);
}

#$flag = &judge_gene($g_start, $g_end, \@r_matchs);
sub judge_gene()
{
    my ($g_start, $g_end, $ar_matchs) = @_ ;

    for (my $i=0; $i<@{$ar_matchs}; $i++){
        my ($r_start, $r_end) = @{$ar_matchs->[$i]} ;
        if ($r_end < $g_start){
            next ;
        }
        elsif ($r_start <= $g_end){
            return(1);
        }
        else{
            last ;
        }
    }

    return(0);
}

#&out_put(\%hid, \%hid_gene, \%hunmap_id, $outfile);
sub out_put()
{
    my ($ahid, $ahid_gene, $ahunmap_id, $outfile) = @_ ;

    #open (OUT, ">$outfile") || die "$outfile, $!\n" ;
    #for my $id (keys %{$ahid}){
    #    print OUT "$id" ;
    #    for (my $i=0; $i<@{$ahid->{$id}}; $i++){
    #        print OUT "\t", $ahid->{$id}[$i] ;
    #    }
    #    print OUT "\n" ;
    #}
    #close(OUT) ;

    open (OUT, ">$outfile.map2gene") || die "$outfile.map2gene, $!\n" ;
    for my $id (keys %{$ahid_gene}){
        print OUT "$id" ;
        for (my $i=0; $i<@{$ahid_gene->{$id}}; $i++){
            print OUT "\t", $ahid_gene->{$id}[$i] ;
        }
        print OUT "\n" ;
    }
    close(OUT);

    open (OUT, ">$outfile.unmapgene.id") || die "$outfile.unmapgene.id, $!\n" ;
    for my $id (keys %{$ahunmap_id}){
        next if (defined $ahid_gene->{$id});
        for (my $i=0; $i<@{$ahunmap_id->{$id}}; $i++){
            print OUT "$id\t", $ahunmap_id->{$id}[$i][0] ;
            for (my $j=1; $j<@{$ahunmap_id->{$id}[$i]}; $j++){
                print OUT "\t", join("\t", @{$ahunmap_id->{$id}[$i][$j]}) ;
            }
            print OUT "\n" ;
        }
    }
    close(OUT);

    return ;
}

