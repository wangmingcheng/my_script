#!/usr/bin/perl -w
# 
# Copyright (c) BIO_MARK 2021
# Writer:         Dengdj <dengdj@biomarker.com.cn>
# Program Date:   2021
# Modifier:       Dengdj <dengdj@biomarker.com.cn>
# Last Modified:  2021
my $ver="1.0";

use strict;
use Getopt::Long;
use Data::Dumper;
use FindBin qw($Bin $Script);
use File::Basename qw(basename dirname);

#####################

my %opts;
GetOptions(\%opts,"i=s","u=s","m=s","o=s","h" );

#&help()if(defined $opts{h});
if(!defined($opts{i}) || !defined($opts{u}) || !defined($opts{m}) || !defined($opts{o}) || defined($opts{h}))
{
	print <<"	Usage End.";
	Description:
		
		Version: $ver

	Usage:

		-i           Log.final.out file                     <infile>     must be given
		-u           uniq.info.stat file                    <infile>     must be given
		-m           mult.info.stat file                    <infile>     must be given
		-o           result file                            <outfile>    must be given
		-h           Help document

	Usage End.

	exit;
}

###############Time
my $Time_Start;
$Time_Start = sub_format_datetime(localtime(time()));
&show_log("Start Time :[$Time_Start]");
################
$| = 1 ;
## get parameters
my $maplogfile = $opts{i} ;
my $uniq_stat_file = $opts{u} ;
my $mult_stat_file = $opts{m} ;
my $outfile = $opts{o} ;

## process
# get in total reads
my %hstat = ();
&reading_log_file($maplogfile, \%hstat);

# get uniq stat info
&reading_uniq_stat_file($uniq_stat_file, \%hstat);

# get mult stat info
&reading_mult_stat_file($mult_stat_file, \%hstat);

# output
&output($outfile, \%hstat);

###############Time
my $Time_End;
$Time_End = sub_format_datetime(localtime(time()));
&show_log("End Time :[$Time_End]");

###############Subs
sub sub_format_datetime {#Time calculation subroutine
    my($sec, $min, $hour, $day, $mon, $year, $wday, $yday, $isdst) = @_;
	$wday = $yday = $isdst = 0;
    sprintf("%4d-%02d-%02d %02d:%02d:%02d", $year+1900, $mon+1, $day, $hour, $min, $sec);
}

sub ABSOLUTE_DIR
{ #$pavfile=&ABSOLUTE_DIR($pavfile);
	my $cur_dir=`pwd`;
	$cur_dir =~ s/\n$//;
	my ($in)=@_;
	my $return="";
	
	if(-f $in)
	{
		my $dir=dirname($in);
		my $file=basename($in);
		chdir $dir;$dir=`pwd`;
		$dir =~ s/\n$// ;
		$return="$dir/$file";
	}
	elsif(-d $in)
	{
		chdir $in;$return=`pwd`;
		$return =~ s/\n$// ;
	}
	else
	{
		warn "Warning just for file and dir [$in]\n";
		exit;
	}
	
	chdir $cur_dir;
	return $return;
}

# &show_log("txt")
sub show_log()
{
	my ($txt) = @_ ;
	my $time = time();
	my $Time = &sub_format_datetime(localtime($time));
	print "$Time:\t$txt\n" ;
	return ($time) ;
}

#&run_or_die($cmd);
sub run_or_die()
{
	my ($cmd) = @_ ;
	my $start_time = &show_log($cmd);
	my $flag = system($cmd) ;
	if ($flag != 0){
		my $end_time = &show_log("Error: command fail: $cmd");
		&show_log("Elaseped time: ".($end_time - $start_time)."s\n");
		exit(1);
	}
	my $end_time = &show_log("done.");
	&show_log("Elaseped time: ".($end_time - $start_time)."s\n");
	return ;
}

## qsub
sub qsub()
{
	my ($shfile, $maxproc) = @_ ;
	my $dir = dirname($shfile) ;
	my $cmd = "cd $dir && sh /share/nas2/genome/bmksoft/tool/qsub_sge_plus/v1.0/qsub_sge.plus.sh --maxproc $maxproc --reqsub --independent $shfile" ;
	&run_or_die($cmd);

	return ;
}

## qsub_mult($shfile, $max_proc, $job_num)
sub qsub_mult()
{
	my ($shfile, $max_proc, $job_num) = @_ ;
	if ($job_num > 500){
		my @shfiles = &cut_shfile($shfile);
		for my $file (@shfiles){
			&qsub($file, $max_proc);
		}
	}
	else{
		&qsub($shfile, $max_proc) ;
	}
}

#my @shfiles = &cut_shfile($shfile);
sub cut_shfile()
{
	my ($file) = @_ ;
	my @files = ();
	my $num = 0 ;
	open (IN, $file) || die "Can't open $file, $!\n" ;
	(my $outprefix = $file) =~ s/.sh$// ;
	while (<IN>){
		chomp ;
		if ($num % 500 == 0){
			close(OUT);
			my $outfile = "$outprefix.sub_".(int($num/500)+1).".sh" ;
			push @files, $outfile ;
			open (OUT, ">$outfile") || die "Can't creat $outfile, $!\n" ;
		}
		print OUT $_, "\n" ;
		$num ++ ;
	}
	close(IN);
	close(OUT);

	return @files ;
}

sub sub_normal_dis_ran(){#$average,$standard_deviation
        my ($aver,$stand_dev) = @_ ;
        my $ran1 = rand() ;
        my $ran2 = rand() ;
        my $y = ((-2*log($ran1))**(0.5))*sin(2*3.1415926535*$ran2) ;
        return ($aver + $stand_dev*$y) ;
}

#&reading_log_file($maplogfile, \%hstat);
sub reading_log_file()
{
    my ($infile, $ahstat) = @_ ;

    open (IN, $infile) || die "$infile, $!\n" ;
    my $total_reads = 0 ;
    while(<IN>){
        chomp ;
        if (m/Number of input reads\s+\|\s+(\d+)/){
            $total_reads = $1 ;
        }
    }
    close(IN);
    $ahstat->{total} = $total_reads ;

    return ;
}

#&reading_uniq_stat_file($uniq_stat_file, \%hstat);
sub reading_uniq_stat_file()
{
    my ($infile, $ahstat) = @_ ;

    open (IN, $infile) || die "$infile, $!\n" ;
    while(<IN>){
        chomp ;
        my ($type, $num) = split ;
        $ahstat->{$type} = $num ;
    }
    close(IN);

    return ;
}

#&reading_mult_stat_file($mult_stat_file, \%hstat);
sub reading_mult_stat_file()
{
    my ($infile, $ahstat) = @_ ;

    open (IN, $infile) || die "$infile, $!\n" ;
    while(<IN>){
        chomp ;
        my ($type, $num) = split ;
        $ahstat->{"mult-".$type} = $num ;
    }
    close(IN);

    return ;
}

#&output($outfile, \%hstat);
sub output()
{
    my ($outfile, $ahstat) = @_ ;

    open (OUT, ">$outfile") || die "$outfile, $!\n" ;
    my $total = defined $ahstat->{total} ? $ahstat->{total} : 0 ;
    my $exonic = defined $ahstat->{Exonic} ? $ahstat->{Exonic} : 0 ;
    my $intergenic = defined $ahstat->{Intergenic} ? $ahstat->{Intergenic} : 0 ;
    my $intronic = defined $ahstat->{Intronic} ? $ahstat->{Intronic} : 0 ;
    my $uniq_transcriptome = defined $ahstat->{Transcriptome} ? $ahstat->{Transcriptome} : 0 ;
    my $mult_transcriptome = defined $ahstat->{"mult-Transcriptome"} ? $ahstat->{"mult-Transcriptome"} : 0 ;
    my $mult = defined $ahstat->{"mult-mult"} ? $ahstat->{"mult-mult"} : 0 ;
    my $mapped = $exonic + $intronic + $intergenic + $mult ;
    my $uniq = $exonic + $intronic + $intergenic + $mult_transcriptome ;
    print OUT "Total reads\t$total\t100%\n" ;
    print OUT "Reads Mapped to Genome\t$mapped\t", int(($mapped/$total)*10000)/100, "%\n" ;
    print OUT "Reads Mapped Confidently to Genome\t$uniq\t", int(($uniq/$total)*10000)/100, "%\n" ;
    print OUT "Reads Mapped Confidently to Intergenic Regions\t$intergenic\t", int(($intergenic/$total)*10000)/100, "%\n" ;
    print OUT "Reads Mapped Confidently to Intronic Regions\t$intronic\t", int(($intronic/$total)*10000)/100, "%\n" ;
    print OUT "Reads Mapped Confidently to Exonic Regions\t", $exonic+$mult_transcriptome, "\t", int(($exonic+$mult_transcriptome)/$total*10000)/100, "%\n" ;
    print OUT "Reads Mapped Confidently to Transcriptome\t", $uniq_transcriptome+$mult_transcriptome, "\t", int(($uniq_transcriptome+$mult_transcriptome)/$total*10000)/100, "%\n" ;
    close(OUT);

    return ;
}

