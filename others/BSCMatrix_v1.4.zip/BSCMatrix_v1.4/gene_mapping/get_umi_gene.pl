#!/usr/bin/perl -w
# 
# Copyright (c) BIO_MARK 2021
# Writer:         Dengdj <dengdj@biomarker.com.cn>
# Program Date:   2021
# Modifier:       Dengdj <dengdj@biomarker.com.cn>
# Last Modified:  2021
my $ver="1.0";

use strict;
use Getopt::Long;
use Data::Dumper;
use FindBin qw($Bin $Script);
use File::Basename qw(basename dirname);

#####################

my %opts;
GetOptions(\%opts,"u=s","g=s","o=s","h" );

#&help()if(defined $opts{h});
if(!defined($opts{u}) || !defined($opts{g}) || !defined($opts{o}) || defined($opts{h}))
{
	print <<"	Usage End.";
	Description:
		
		Version: $ver

	Usage:

		-u           reads umi info file                   <infile>     must be given
		-g           reads gene file                       <infile>     must be given
		-o           result file                           <outfile>    must be given
		-h           Help document

	Usage End.

	exit;
}

###############Time
my $Time_Start;
$Time_Start = sub_format_datetime(localtime(time()));
&show_log("Start Time :[$Time_Start]");
################
$| = 1 ;
## get parameters
my $umifile = $opts{u} ;
my $genefile = $opts{g} ;
my $outfile = $opts{o} ;

## get gene info
my %hgene = ();
&get_gene_info($genefile, \%hgene);

## get reads umi info
my %humi = ();
&get_umi_info($umifile, \%humi);

## get umi gene
my %humi_gene = ();
my %humi_gene_info = ();
&get_umi_gene(\%hgene, \%humi, \%humi_gene, \%humi_gene_info);

## out put
&out_put(\%humi_gene, \%humi_gene_info, $outfile);

###############Time
my $Time_End;
$Time_End = sub_format_datetime(localtime(time()));
&show_log("End Time :[$Time_End]");

###############Subs
sub sub_format_datetime {#Time calculation subroutine
    my($sec, $min, $hour, $day, $mon, $year, $wday, $yday, $isdst) = @_;
	$wday = $yday = $isdst = 0;
    sprintf("%4d-%02d-%02d %02d:%02d:%02d", $year+1900, $mon+1, $day, $hour, $min, $sec);
}

sub ABSOLUTE_DIR
{ #$pavfile=&ABSOLUTE_DIR($pavfile);
	my $cur_dir=`pwd`;
	$cur_dir =~ s/\n$//;
	my ($in)=@_;
	my $return="";
	
	if(-f $in)
	{
		my $dir=dirname($in);
		my $file=basename($in);
		chdir $dir;$dir=`pwd`;
		$dir =~ s/\n$// ;
		$return="$dir/$file";
	}
	elsif(-d $in)
	{
		chdir $in;$return=`pwd`;
		$return =~ s/\n$// ;
	}
	else
	{
		warn "Warning just for file and dir [$in]\n";
		exit;
	}
	
	chdir $cur_dir;
	return $return;
}

# &show_log("txt")
sub show_log()
{
	my ($txt) = @_ ;
	my $time = time();
	my $Time = &sub_format_datetime(localtime($time));
	print "$Time:\t$txt\n" ;
	return ($time) ;
}

#&run_or_die($cmd);
sub run_or_die()
{
	my ($cmd) = @_ ;
	my $start_time = &show_log($cmd);
	my $flag = system($cmd) ;
	if ($flag != 0){
		my $end_time = &show_log("Error: command fail: $cmd");
		&show_log("Elaseped time: ".($end_time - $start_time)."s\n");
		exit(1);
	}
	my $end_time = &show_log("done.");
	&show_log("Elaseped time: ".($end_time - $start_time)."s\n");
	return ;
}

## qsub
sub qsub()
{
	my ($shfile, $maxproc) = @_ ;
	my $dir = dirname($shfile) ;
	my $cmd = "cd $dir && sh /share/nas2/genome/bmksoft/tool/qsub_sge_plus/v1.0/qsub_sge.plus.sh --maxproc $maxproc --reqsub --independent $shfile" ;
	&run_or_die($cmd);

	return ;
}

## qsub_mult($shfile, $max_proc, $job_num)
sub qsub_mult()
{
	my ($shfile, $max_proc, $job_num) = @_ ;
	if ($job_num > 500){
		my @shfiles = &cut_shfile($shfile);
		for my $file (@shfiles){
			&qsub($file, $max_proc);
		}
	}
	else{
		&qsub($shfile, $max_proc) ;
	}
}

#my @shfiles = &cut_shfile($shfile);
sub cut_shfile()
{
	my ($file) = @_ ;
	my @files = ();
	my $num = 0 ;
	open (IN, $file) || die "Can't open $file, $!\n" ;
	(my $outprefix = $file) =~ s/.sh$// ;
	while (<IN>){
		chomp ;
		if ($num % 500 == 0){
			close(OUT);
			my $outfile = "$outprefix.sub_".(int($num/500)+1).".sh" ;
			push @files, $outfile ;
			open (OUT, ">$outfile") || die "Can't creat $outfile, $!\n" ;
		}
		print OUT $_, "\n" ;
		$num ++ ;
	}
	close(IN);
	close(OUT);

	return @files ;
}

sub sub_normal_dis_ran(){#$average,$standard_deviation
        my ($aver,$stand_dev) = @_ ;
        my $ran1 = rand() ;
        my $ran2 = rand() ;
        my $y = ((-2*log($ran1))**(0.5))*sin(2*3.1415926535*$ran2) ;
        return ($aver + $stand_dev*$y) ;
}

#&get_gene_info($genefile, \%hgene);
sub get_gene_info()
{
    my ($genefile, $ahgene) = @_ ;

    open (IN, $genefile) || die "$genefile, $!\n" ;
    while(<IN>){
        chomp ;
        next if (m/^\s*$|^\#/);
        my ($id, @genes) = split ;
        $ahgene->{$id} = \@genes ;
    }
    close(IN);

    return ;
}

#&get_umi_info($umifile, \%humi);
sub get_umi_info()
{
    my ($umifile, $ahumi) = @_ ;

    open (IN, $umifile) || die "$umifile, $!\n" ;
    while(<IN>){
        chomp ;
        next if (m/^\#|^\s*$/);
        my ($id, $bc, $pos, $umi) = split ;
        push @{$ahumi->{$bc}{$umi}}, $id ;
    }
    close(IN);

    return ;
}

#&get_umi_gene(\%hgene, \%humi, \%humi_gene, \%humi_gene_info);
sub get_umi_gene()
{
    my ($ahgene, $ahumi, $ahumi_gene, $ahumi_gene_info) = @_ ;

    for my $type (keys %{$ahumi}){
        for my $umi (keys %{$ahumi->{$type}}){
            my %hstat = ();
            for my $id (@{$ahumi->{$type}{$umi}}){
                if (defined $ahgene->{$id}){
                    for my $gene (@{$ahgene->{$id}}){
                        $hstat{$gene}++ ;
                    }
                }
            }
            my @genes = sort {$hstat{$b}<=>$hstat{$a}} keys %hstat ;
            if (scalar @genes > 0){
                $ahumi_gene->{$type}{$umi} = $genes[0] ;
                for my $gene (@genes){
                    push @{$ahumi_gene_info->{$type}{$umi}}, [$gene, $hstat{$gene}] ;
                }
            }
        }
    }

    return ;
}

#&out_put(\%humi_gene, \%humi_gene_info, $outfile);
sub out_put()
{
    my ($ahumi_gene, $ahumi_gene_info, $outfile) = @_ ;

    open (OUT, ">$outfile") || die "$outfile, $!\n" ;
    open (INF, ">$outfile.info") || die "$outfile.info, $!\n" ;
    for my $type (sort keys %{$ahumi_gene}){
        if ($type =~ m/bc1_\d+\-bc2_\d+\-bc3_\d+/){
            for my $umi (sort keys %{$ahumi_gene->{$type}}){
                my $gene = $ahumi_gene->{$type}{$umi} ;
                print OUT "$type\t$umi\t$gene\n" ;
                print INF "$type\t$umi" ;
                for (my $i=0; $i<@{$ahumi_gene_info->{$type}{$umi}}; $i++){
                    my ($gene, $num) = @{$ahumi_gene_info->{$type}{$umi}[$i]};
                    print INF "\t$gene\t$num" ;
                }
                print INF "\n" ;
            }
        }
        else{
            for my $umi (sort keys %{$ahumi_gene->{$type}}){
                print INF "$type\t$umi" ;
                for (my $i=0; $i<@{$ahumi_gene_info->{$type}{$umi}}; $i++){
                    my ($gene, $num) = @{$ahumi_gene_info->{$type}{$umi}[$i]};
                    print INF "\t$gene\t$num" ;
                }
                print INF "\n" ;
            }
        }
    }
    close(OUT);
    close(INF);

    return ;
}

