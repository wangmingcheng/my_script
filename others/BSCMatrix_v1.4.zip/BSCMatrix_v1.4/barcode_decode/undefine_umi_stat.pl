#!/usr/bin/perl -w
# 
# Copyright (c) BIO_MARK 2021
# Writer:         Dengdj <dengdj@biomarker.com.cn>
# Program Date:   2021
# Modifier:       Dengdj <dengdj@biomarker.com.cn>
# Last Modified:  2021
my $ver="1.0";

use strict;
use Getopt::Long;
use Data::Dumper;
use FindBin qw($Bin $Script);
use File::Basename qw(basename dirname);

#####################

my %opts;
GetOptions(\%opts,"i=s","u=s","o=s","h" );

#&help()if(defined $opts{h});
if(!defined($opts{i}) || !defined($opts{u}) || !defined($opts{o}) || defined($opts{h}))
{
	print <<"	Usage End.";
	Description:
		
		Version: $ver

	Usage:

		-i           decode pos file                                 <infile>     must be given
		-u           umi gene file                                   <infile>     must be given
		-o           result file                                     <outfile>    must be given
		-h           Help document

	Usage End.

	exit;
}

###############Time
my $Time_Start;
$Time_Start = sub_format_datetime(localtime(time()));
&show_log("Start Time :[$Time_Start]");
################
$| = 1 ;
## get parameters
my $posfile = $opts{i} ;
my $genefile = $opts{u} ;
my $outfile = $opts{o} ;

## reading pos file
my %hbc = ();
&get_bc_info($posfile, \%hbc);

## reading gene umi file
my %hgene = ();
&reading_gene_umi_file($genefile, \%hgene);

## stat and output
&stat_and_output(\%hbc, \%hgene, $outfile);

###############Time
my $Time_End;
$Time_End = sub_format_datetime(localtime(time()));
&show_log("End Time :[$Time_End]");

###############Subs
sub sub_format_datetime {#Time calculation subroutine
    my($sec, $min, $hour, $day, $mon, $year, $wday, $yday, $isdst) = @_;
	$wday = $yday = $isdst = 0;
    sprintf("%4d-%02d-%02d %02d:%02d:%02d", $year+1900, $mon+1, $day, $hour, $min, $sec);
}

sub ABSOLUTE_DIR
{ #$pavfile=&ABSOLUTE_DIR($pavfile);
	my $cur_dir=`pwd`;
	$cur_dir =~ s/\n$//;
	my ($in)=@_;
	my $return="";
	
	if(-f $in)
	{
		my $dir=dirname($in);
		my $file=basename($in);
		chdir $dir;$dir=`pwd`;
		$dir =~ s/\n$// ;
		$return="$dir/$file";
	}
	elsif(-d $in)
	{
		chdir $in;$return=`pwd`;
		$return =~ s/\n$// ;
	}
	else
	{
		warn "Warning just for file and dir [$in]\n";
		exit;
	}
	
	chdir $cur_dir;
	return $return;
}

# &show_log("txt")
sub show_log()
{
	my ($txt) = @_ ;
	my $time = time();
	my $Time = &sub_format_datetime(localtime($time));
	print "$Time:\t$txt\n" ;
	return ($time) ;
}

#&run_or_die($cmd);
sub run_or_die()
{
	my ($cmd) = @_ ;
	my $start_time = &show_log($cmd);
	my $flag = system($cmd) ;
	if ($flag != 0){
		my $end_time = &show_log("Error: command fail: $cmd");
		&show_log("Elaseped time: ".($end_time - $start_time)."s\n");
		exit(1);
	}
	my $end_time = &show_log("done.");
	&show_log("Elaseped time: ".($end_time - $start_time)."s\n");
	return ;
}

## qsub
sub qsub()
{
	my ($shfile, $maxproc) = @_ ;
	my $dir = dirname($shfile) ;
	my $cmd = "cd $dir && sh /share/nas2/genome/bmksoft/tool/qsub_sge_plus/v1.0/qsub_sge.plus.sh --maxproc $maxproc --reqsub --independent $shfile" ;
	&run_or_die($cmd);

	return ;
}

## qsub_mult($shfile, $max_proc, $job_num)
sub qsub_mult()
{
	my ($shfile, $max_proc, $job_num) = @_ ;
	if ($job_num > 500){
		my @shfiles = &cut_shfile($shfile);
		for my $file (@shfiles){
			&qsub($file, $max_proc);
		}
	}
	else{
		&qsub($shfile, $max_proc) ;
	}
}

#my @shfiles = &cut_shfile($shfile);
sub cut_shfile()
{
	my ($file) = @_ ;
	my @files = ();
	my $num = 0 ;
	open (IN, $file) || die "Can't open $file, $!\n" ;
	(my $outprefix = $file) =~ s/.sh$// ;
	while (<IN>){
		chomp ;
		if ($num % 500 == 0){
			close(OUT);
			my $outfile = "$outprefix.sub_".(int($num/500)+1).".sh" ;
			push @files, $outfile ;
			open (OUT, ">$outfile") || die "Can't creat $outfile, $!\n" ;
		}
		print OUT $_, "\n" ;
		$num ++ ;
	}
	close(IN);
	close(OUT);

	return @files ;
}

sub sub_normal_dis_ran(){#$average,$standard_deviation
        my ($aver,$stand_dev) = @_ ;
        my $ran1 = rand() ;
        my $ran2 = rand() ;
        my $y = ((-2*log($ran1))**(0.5))*sin(2*3.1415926535*$ran2) ;
        return ($aver + $stand_dev*$y) ;
}

#&get_bc_info($posfile, \%hbc);
sub get_bc_info()
{
    my ($posfile, $ahbc) = @_ ;

    open (IN, $posfile) || die "$posfile, $!\n" ;
    while(<IN>){
        chomp ;
        next if (m/^\#|^\s*$/);
        my ($id, $p1, $p2, $p3, $p4, $bc, $type) = split ;
        $ahbc->{$bc} = $type ;
    }
    close(IN);

    return ;
}

#&reading_gene_umi_file($genefile, \%hgene);
sub reading_gene_umi_file()
{
    my ($genefile, $ahgene) = @_ ;

    open (IN, $genefile) || die "$genefile, $!\n" ;
    while(<IN>){
        chomp ;
        next if (m/^\s*$|^\#/);
        my ($bc, $umi, $gene) = split ;
        push @{$ahgene->{$gene}{$bc}}, $umi ;
    }
    close(IN);

    return ;
}

#&stat_and_output(\%hbc, \%hgene, $outfile);
sub stat_and_output()
{
    my ($ahbc, $ahgene, $outfile) = @_ ;

    open (OUT, ">$outfile") || die "$outfile, $!\n" ;
    my %hstat = ();
    for my $gene (keys %{$ahgene}){
        for my $bc (keys %{$ahgene->{$gene}}){
            if (!defined $ahbc->{$bc}){
                my $num = scalar(@{$ahgene->{$gene}{$bc}}) ;
                $hstat{'undef'} += $num ;
                print OUT "$gene\t$bc\t$num\tundef\n" ;
            }
            else{
                if ($ahbc->{$bc} eq 'Dup'){
                    my $num = scalar(@{$ahgene->{$gene}{$bc}}) ;
                    $hstat{'dup'} += $num ;
                    print OUT "$gene\t$bc\t$num\tdup\n" ;
                }
                elsif($ahbc->{$bc} eq 'U'){
                    my $num = scalar(@{$ahgene->{$gene}{$bc}}) ;
                    $hstat{'notfind'} += $num ;
                    print OUT "$gene\t$bc\t$num\tnotfind\n" ;
                }
                else{
                    my $num = scalar(@{$ahgene->{$gene}{$bc}}) ;
                    $hstat{'fine'} += $num ;
                }
            }
        }
    }
    close(OUT);

    open (OUT, ">$outfile.stat") || die "$outfile.stat, $!\n" ;
    for my $type (qw/fine undef dup notfind/){
        my $num = defined $hstat{$type} ? $hstat{$type} : 0 ;
        print OUT "$type\t$num\n" ;
    }
    close(OUT);

    return ;
}

