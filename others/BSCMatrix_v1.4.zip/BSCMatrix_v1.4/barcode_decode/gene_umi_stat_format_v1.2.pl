#!/usr/bin/perl -w
# 
# Copyright (c) BIO_MARK 2021
# Writer:         Dengdj <dengdj@biomarker.com.cn>
# Program Date:   2021
# Modifier:       Dengdj <dengdj@biomarker.com.cn>
# Last Modified:  2021
my $ver="1.0";

use strict;
use Getopt::Long;
use Data::Dumper;
use FindBin qw($Bin $Script);
use File::Basename qw(basename dirname);

#####################

my %opts;
GetOptions(\%opts,"i=s","g=s","o=s","s=s","h" );

#&help()if(defined $opts{h});
if(!defined($opts{i}) || !defined($opts{g}) || !defined($opts{o}) || defined($opts{h}))
{
	print <<"	Usage End.";
	Description:
		
		Version: $ver

	Usage:

		-i           decode pos file            <infile>     must be given
		-g           umi gene file              <infile>     must be given
		-o           result file                <outfile>    must be given
		-s           zoom scalar                [int]        optional [7] 
		-h           Help document

	Usage End.

	exit;
}

###############Time
my $Time_Start;
$Time_Start = sub_format_datetime(localtime(time()));
&show_log("Start Time :[$Time_Start]");
################
$| = 1 ;
## get parameters
my $posfile = $opts{i} ;
my $genefile = $opts{g} ;
my $outfile = $opts{o} ;
my $scalar = defined $opts{s} ? $opts{s} : 7 ;

## reading pos info file
my %hpos = ();
&reading_pos_file($posfile, $scalar, \%hpos);

## reading gene file
my %hgene = () ;
&reading_gene_file($genefile, \%hgene);

## out put
&output(\%hgene, \%hpos, $outfile);

###############Time
my $Time_End;
$Time_End = sub_format_datetime(localtime(time()));
&show_log("End Time :[$Time_End]");

###############Subs
sub sub_format_datetime {#Time calculation subroutine
    my($sec, $min, $hour, $day, $mon, $year, $wday, $yday, $isdst) = @_;
	$wday = $yday = $isdst = 0;
    sprintf("%4d-%02d-%02d %02d:%02d:%02d", $year+1900, $mon+1, $day, $hour, $min, $sec);
}

sub ABSOLUTE_DIR
{ #$pavfile=&ABSOLUTE_DIR($pavfile);
	my $cur_dir=`pwd`;
	$cur_dir =~ s/\n$//;
	my ($in)=@_;
	my $return="";
	
	if(-f $in)
	{
		my $dir=dirname($in);
		my $file=basename($in);
		chdir $dir;$dir=`pwd`;
		$dir =~ s/\n$// ;
		$return="$dir/$file";
	}
	elsif(-d $in)
	{
		chdir $in;$return=`pwd`;
		$return =~ s/\n$// ;
	}
	else
	{
		warn "Warning just for file and dir [$in]\n";
		exit;
	}
	
	chdir $cur_dir;
	return $return;
}

# &show_log("txt")
sub show_log()
{
	my ($txt) = @_ ;
	my $time = time();
	my $Time = &sub_format_datetime(localtime($time));
	print "$Time:\t$txt\n" ;
	return ($time) ;
}

#&run_or_die($cmd);
sub run_or_die()
{
	my ($cmd) = @_ ;
	my $start_time = &show_log($cmd);
	my $flag = system($cmd) ;
	if ($flag != 0){
		my $end_time = &show_log("Error: command fail: $cmd");
		&show_log("Elaseped time: ".($end_time - $start_time)."s\n");
		exit(1);
	}
	my $end_time = &show_log("done.");
	&show_log("Elaseped time: ".($end_time - $start_time)."s\n");
	return ;
}

## qsub
sub qsub()
{
	my ($shfile, $maxproc) = @_ ;
	my $dir = dirname($shfile) ;
	my $cmd = "cd $dir && sh /share/nas2/genome/bmksoft/tool/qsub_sge_plus/v1.0/qsub_sge.plus.sh --maxproc $maxproc --reqsub --independent $shfile" ;
	&run_or_die($cmd);

	return ;
}

## qsub_mult($shfile, $max_proc, $job_num)
sub qsub_mult()
{
	my ($shfile, $max_proc, $job_num) = @_ ;
	if ($job_num > 500){
		my @shfiles = &cut_shfile($shfile);
		for my $file (@shfiles){
			&qsub($file, $max_proc);
		}
	}
	else{
		&qsub($shfile, $max_proc) ;
	}
}

#my @shfiles = &cut_shfile($shfile);
sub cut_shfile()
{
	my ($file) = @_ ;
	my @files = ();
	my $num = 0 ;
	open (IN, $file) || die "Can't open $file, $!\n" ;
	(my $outprefix = $file) =~ s/.sh$// ;
	while (<IN>){
		chomp ;
		if ($num % 500 == 0){
			close(OUT);
			my $outfile = "$outprefix.sub_".(int($num/500)+1).".sh" ;
			push @files, $outfile ;
			open (OUT, ">$outfile") || die "Can't creat $outfile, $!\n" ;
		}
		print OUT $_, "\n" ;
		$num ++ ;
	}
	close(IN);
	close(OUT);

	return @files ;
}

#&reading_pos_file($posfile, $scalar, \%hpos);
sub reading_pos_file()
{
    my ($posfile, $scalar, $ahpos) = @_ ;

    ## init para
    my $block_row_num = 46 ;
    my $block_col_num = 46 ;
    my $row_num = 35 ;
    my $col_num = 30 ;

    open (IN, $posfile) || die "$posfile, $!\n" ;
    while(<IN>){
        chomp ;
        my ($id, $p1, $p2, $p3, $p4, $type, undef) = split ;
        next if ("$p1$p2$p3$p4" eq "-1-1-1-1") ;
        my $x = $p2*($col_num+1) + $p4 ;
        my $y = $p1*($row_num+1) + $p3 ;
        my $x_i = int($x/$scalar) ;
        my $y_i = int($y/$scalar) ;
        $ahpos->{"$x_i-$y_i"}{$type}++ ;
    }
    close(IN);

    return ;
}

#&reading_gene_file($genefile, \%hgene);
sub reading_gene_file()
{
    my ($genefile, $ahgene) = @_ ;

    open (IN, $genefile) || die "$genefile, $!\n" ;
    while(<IN>){
        chomp ;
        next if (m/^\#|^\s*$/) ;
        my ($type, $umi, $gene) = split ;
        $ahgene->{$type}{$umi}{$gene}++ ;
    }
    close(IN);

    return ;
}

#&output(\%hgene, \%hpos, $outfile);
sub output()
{
    my ($ahgene, $ahpos, $outfile) = @_ ;

    my %hstat = ();
    for my $spot (keys %{$ahpos}){
        for my $type (keys %{$ahpos->{$spot}}){
            for my $umi (keys %{$ahgene->{$type}}){
                for my $gene (keys %{$ahgene->{$type}{$umi}}){
                    $hstat{$gene}{$spot}{"$type-$umi"}++ ;
                }
            }
        }
    }

    open (OUT, ">$outfile") || die "$outfile, $!\n" ;
    print OUT "#Gene" ;
    my @spots = sort keys %{$ahpos};
    for my $spot (@spots){
        print OUT "\t$spot";
    }
    print OUT "\n" ;
    for my $gene (keys %hstat){
        print OUT "$gene" ;
        for my $spot (@spots){
            if (!defined $hstat{$gene}{$spot}){
                print OUT "\t0" ;
            }
            else{
                my $num = scalar (keys %{$hstat{$gene}{$spot}});
                print OUT "\t$num" ;
            }
        }
        print OUT "\n" ;
    }
    close(OUT);

    return ;
}

