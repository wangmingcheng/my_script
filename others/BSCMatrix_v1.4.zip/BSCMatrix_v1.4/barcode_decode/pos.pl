#!/usr/bin/perl -w
use strict ;

if (@ARGV != 2){
    print "Usage: perl $0 infile outfile\n" ;
    exit(1);
}

my ($infile, $outfile) = @ARGV ;

open (IN, $infile) || die "$infile, $!\n" ;
my %hpos = ();
while(<IN>){
    chomp ;
    next if (m/^\#|^\s*$/);
    my ($id, $p1, $p2, $p3, $p4, $bc, $flag) = split ;
    next if ("$p1$p2$p3$p4" eq "-1-1-1-1") ;
    $hpos{$bc}{"$p1\t$p2\t$p3\t$p4"}++ ;
}
close(IN);

open (OUT, ">$outfile") || die "$outfile, $!\n" ;
for my $bc (sort keys %hpos){
    my @poses = keys %{$hpos{$bc}} ;
    if (scalar @poses > 1){
        print "barcode has mult pos:\n" ;
        print "$bc\t@poses\n" ;
        exit(1);
    }
    print OUT "$bc\t$poses[0]\n" ;
}
close(OUT);

