$(document).ready(function(){

            $(".img-toggle").fancybox({
                openEffect	: 'elastic',
                closeEffect	: 'elastic',

                helpers : {
                    title : {
                        type : 'inside'
                    }
                }
            });

        });