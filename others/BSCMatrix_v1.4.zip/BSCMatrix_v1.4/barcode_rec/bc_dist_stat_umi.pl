#!/usr/bin/perl -w
use strict ;

if (@ARGV < 2){
    print "Usage: perl $0 full.stat.file outfile [min number:10]\n" ;
    exit(1);
}

my ($infile, $outfile, $min_num) = @ARGV ;
if (!defined $min_num){
    $min_num = 10 ;
}
open (IN, $infile) || die "$infile, $!\n" ;
my %hbc = ();
my %humi = ();
while(<IN>){
    chomp ;
    next if (m/^\#|^\s*$/);
    my ($type, $num, $umi) = split ;
    next if ($num < $min_num) ;
    my @bcs = split /\-/, $type ;
    for my $bc (@bcs){
        if ($bc =~ m/(bc\d)_\d+/){
            $hbc{$1}{$bc} += $num ;
            $humi{$1}{$bc} += $umi ;
        }
    }
}
close(IN);

open (OUT, ">$outfile") || die "$outfile, $!\n" ;
print OUT "#Type\tBarcode\tNumber\tUMI\n" ;
for my $type (sort keys %hbc){
    for my $bc (sort {$hbc{$type}{$b}<=>$hbc{$type}{$a}} keys %{$hbc{$type}}){
        #print OUT "$type\t$bc\t", $hbc{$type}{$bc}, "\n" ;
        print OUT "$type\t$bc\t", $hbc{$type}{$bc}, "\t", $humi{$type}{$bc}, "\n" ;
    }
}
close(OUT) ;

