#!/usr/bin/perl -w
use strict ;

if (@ARGV < 2){
    print "Usage: perl $0 bc.out.file outfile [minkmer:15]\n" ;
    exit(1);
}

my ($infile, $outfile, $minkmer) = @ARGV ;
$minkmer ||= 15 ;

open (IN, $infile) || die "$infile, $!\n" ;
open (OUT, ">$outfile.detail") || die "$outfile.detail, $!\n" ;
my %hstat = ();
while(<IN>){
    chomp ;
    next if (m/^\#|^\s*$/);
    my ($id, @types) = split ;
    my $out = "$id" ;
    my $flag = 0 ;
    for my $info (@types){
        my ($type, $num) = split /\:/, $info ;
        next if ($type !~ m/bc/);
        if ($num > $minkmer){
            $hstat{$type}++ ;
            $out .= "\t$info" ;
            $flag = 1 ;
        }
    }
    if ($flag == 1){
        print OUT "$out\n" ;
    }
}
close(IN);
close(OUT);

open (OUT, ">$outfile") || die "$outfile, $!\n" ;
for my $type (sort {$hstat{$b}<=>$hstat{$a}} keys %hstat){
    my $num = $hstat{$type} ;
    print OUT "$type\t$num\n" ;
}
close(OUT);

