#!/usr/bin/perl -w
use strict ;

if (@ARGV != 2){
    print "Usage: perl $0 bc-type-file outfile\n" ;
    exit(1);
}

my ($infile, $outfile) = @ARGV ;

open (IN, $infile) || die "$infile, $!\n" ;
my $read_num = 0 ;
my $offset_num = 0 ;
my $full_num = 0 ;
my $full_offset = 0 ;
while(<IN>){
    chomp ;
    next if (m/^\s*$|^\#/);
    my ($id, $type, $pos) = split ;
    $read_num++ ;
    next if ($type =~ m/null/i);
    next if ($type !~ m/bc3/) ;
    my @poses = split /\-/, $pos;
    my $bc3_pos = $poses[-1] ;
    my ($ref, $map) = split /\,/, $bc3_pos ;
    my $off_flag = 0;
    if (abs($ref-$map) > 5){
        $offset_num++ ;
        $off_flag = 1 ;
    }
    if (scalar(@poses) == 3){
        $full_num++ ;
        if ($off_flag == 1){
            $full_offset++ ;
        }
    }
}
close(IN);

open (OUT, ">$outfile") || die "$outfile, $!\n" ;
print OUT "Total\t$read_num\t100\n" ;
my $full_rate = int(($full_num/$read_num)*10000)/100 ;
print OUT "FullBC\t$full_num\t$full_rate\n" ;
my $full_offset_rate = int(($full_offset/$read_num)*10000)/100 ;
print OUT "FullOffset\t$full_offset\t$full_offset_rate\n" ;
my $offset_rate = int($offset_num/$read_num*10000)/100 ;
print OUT "Offset\t$offset_num\t$offset_rate\n" ;
close(OUT);

