#!/usr/bin/perl -w
use strict ;

if (@ARGV < 3){
    print "Usage: perl $0 unmap_gene_id mapgene_id outfile\n" ;
    exit(1);
}

my ($unmapfile, $mapfile, $outfile) = @ARGV ;

open (IN, $mapfile) || die "$mapfile, $!\n" ;
my %hid = ();
while(<IN>){
    chomp ;
    my ($id) = split ;
    $hid{$id} = 1 ;
}
close(IN);

open (IN, $unmapfile) || die "$unmapfile, $!\n" ;
my %hunmap = ();
while(<IN>){
    chomp ;
    my ($id) = split ;
    next if (defined $hid{$id}) ;
    $hunmap{$id} = 1 ;
}
close(IN);

open(OUT, ">$outfile") || die "$outfile, $!\n" ;
for my $id (keys %hunmap){
    print OUT "$id\n" ;
}
close(OUT);

open (OUT, ">$outfile.stat") || die "$outfile.stat, $!\n"  ;
my $map = scalar (keys %hid) ;
my $unmap = scalar (keys %hunmap) ;
print OUT "map:\t$map\n" ;
print OUT "unmap:\t$unmap\n" ;
close(OUT);

